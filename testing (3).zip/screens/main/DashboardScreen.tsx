"use client"

import { useState, useEffect } from "react"
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, RefreshControl } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useNavigation } from "@react-navigation/native"
import { Ionicons } from "@expo/vector-icons"
import { useAuth } from "../../context/AuthContext"
import { getSubRequests } from "../../services/subRequestService"

export default function DashboardScreen() {
  const navigation = useNavigation()
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState(user?.role === "team" ? "team" : "player")
  const [subRequests, setSubRequests] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    loadSubRequests()
  }, [])

  const loadSubRequests = async () => {
    try {
      const requests = await getSubRequests()
      setSubRequests(requests)
    } catch (error) {
      console.error("Error fetching sub requests:", error)
    } finally {
      setIsLoading(false)
      setRefreshing(false)
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    loadSubRequests()
  }

  // Format date for display
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  // Format time for display
  const formatTime = (timeString) => {
    if (!timeString) return ""
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    return `${hour > 12 ? hour - 12 : hour}:${minutes} ${hour >= 12 ? "PM" : "AM"}`
  }

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2563eb" />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    )
  }

  return (
    <SafeAreaView style={styles.container} edges={["bottom"]}>
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "player" && styles.activeTab]}
          onPress={() => setActiveTab("player")}
        >
          <Text style={[styles.tabText, activeTab === "player" && styles.activeTabText]}>Player View</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === "team" && styles.activeTab]}
          onPress={() => setActiveTab("team")}
        >
          <Text style={[styles.tabText, activeTab === "team" && styles.activeTabText]}>Team Manager View</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {activeTab === "player" ? (
          <View style={styles.content}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Available Sub Opportunities</Text>
              <Text style={styles.sectionSubtitle}>Games looking for substitute players</Text>
            </View>

            {subRequests.length > 0 ? (
              subRequests.map((game) => (
                <View key={game.id} style={styles.card}>
                  <View style={styles.cardContent}>
                    <View style={styles.cardHeader}>
                      <Text style={styles.cardTitle}>{game.teamName}</Text>
                    </View>
                    <View style={styles.cardDetails}>
                      <View style={styles.detailRow}>
                        <Ionicons name="calendar-outline" size={16} color="#666" />
                        <Text style={styles.detailText}>{formatDate(game.date)}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Ionicons name="time-outline" size={16} color="#666" />
                        <Text style={styles.detailText}>{formatTime(game.time)}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Ionicons name="location-outline" size={16} color="#666" />
                        <Text style={styles.detailText}>{game.location}</Text>
                      </View>
                    </View>
                    <View style={styles.positionsContainer}>
                      <Text style={styles.positionsLabel}>Positions Needed:</Text>
                      <View style={styles.positionTags}>
                        {game.positionsNeeded.map((position) => (
                          <View key={position} style={styles.positionTag}>
                            <Text style={styles.positionTagText}>
                              {position.charAt(0).toUpperCase() + position.slice(1)}
                            </Text>
                          </View>
                        ))}
                      </View>
                    </View>
                    <TouchableOpacity style={styles.applyButton}>
                      <Text style={styles.applyButtonText}>Apply to Sub</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))
            ) : (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateText}>No games currently looking for subs</Text>
              </View>
            )}

            <View style={styles.card}>
              <View style={styles.cardContent}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardTitle}>My Availability</Text>
                  <Text style={styles.cardSubtitle}>Set when you're available to play</Text>
                </View>
                <View style={styles.availabilityContainer}>
                  {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => (
                    <TouchableOpacity key={day} style={styles.dayButton}>
                      <Text style={styles.dayButtonText}>{day}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
                <TouchableOpacity style={styles.updateButton}>
                  <Text style={styles.updateButtonText}>Update Availability</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ) : (
          <View style={styles.content}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionTitleContainer}>
                <Text style={styles.sectionTitle}>My Sub Requests</Text>
                <Text style={styles.sectionSubtitle}>Manage your team's substitute requests</Text>
              </View>
              <TouchableOpacity style={styles.newRequestButton} onPress={() => navigation.navigate("RequestSub")}>
                <Ionicons name="add" size={18} color="#fff" />
                <Text style={styles.newRequestButtonText}>New Request</Text>
              </TouchableOpacity>
            </View>

            {subRequests.length > 0 ? (
              subRequests.map((request) => (
                <View key={request.id} style={styles.card}>
                  <View style={styles.cardContent}>
                    <View style={styles.cardHeader}>
                      <Text style={styles.cardTitle}>{request.teamName}</Text>
                    </View>
                    <View style={styles.cardDetails}>
                      <View style={styles.detailRow}>
                        <Ionicons name="calendar-outline" size={16} color="#666" />
                        <Text style={styles.detailText}>{formatDate(request.date)}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Ionicons name="time-outline" size={16} color="#666" />
                        <Text style={styles.detailText}>{formatTime(request.time)}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Ionicons name="location-outline" size={16} color="#666" />
                        <Text style={styles.detailText}>{request.location}</Text>
                      </View>
                    </View>
                    <View style={styles.positionsContainer}>
                      <Text style={styles.positionsLabel}>Positions Needed:</Text>
                      <View style={styles.positionTags}>
                        {request.positionsNeeded.map((position) => (
                          <View key={position} style={styles.positionTag}>
                            <Text style={styles.positionTagText}>
                              {position.charAt(0).toUpperCase() + position.slice(1)}
                            </Text>
                          </View>
                        ))}
                      </View>
                    </View>
                    <View style={styles.buttonRow}>
                      <TouchableOpacity style={styles.editButton}>
                        <Text style={styles.editButtonText}>Edit</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={styles.viewButton}>
                        <Text style={styles.viewButtonText}>View Applicants</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              ))
            ) : (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateText}>You haven't created any sub requests yet</Text>
                <TouchableOpacity style={styles.createButton} onPress={() => navigation.navigate("RequestSub")}>
                  <Ionicons name="add" size={18} color="#fff" style={styles.createButtonIcon} />
                  <Text style={styles.createButtonText}>Create Sub Request</Text>
                </TouchableOpacity>
              </View>
            )}

            <View style={styles.card}>
              <View style={styles.cardContent}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardTitle}>My Teams</Text>
                  <Text style={styles.cardSubtitle}>Manage your hockey teams</Text>
                </View>
                <View style={styles.teamCard}>
                  <View style={styles.teamInfo}>
                    <Text style={styles.teamName}>Maple Leafs</Text>
                    <Text style={styles.teamLeague}>City League</Text>
                    <View style={styles.detailRow}>
                      <Ionicons name="people-outline" size={16} color="#666" />
                      <Text style={styles.detailText}>15 players</Text>
                    </View>
                  </View>
                  <View style={styles.teamButtons}>
                    <TouchableOpacity style={styles.manageButton}>
                      <Text style={styles.manageButtonText}>Manage Team</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.requestButton} onPress={() => navigation.navigate("RequestSub")}>
                      <Text style={styles.requestButtonText}>Request Subs</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: "#666",
  },
  tabContainer: {
    flexDirection: "row",
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
  },
  tab: {
    flex: 1,
    paddingVertical: 15,
    alignItems: "center",
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: "#2563eb",
  },
  tabText: {
    fontSize: 16,
    color: "#666",
  },
  activeTabText: {
    color: "#2563eb",
    fontWeight: "600",
  },
  scrollContent: {
    padding: 16,
  },
  content: {
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  sectionTitleContainer: {
    flex: 1,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
  },
  sectionSubtitle: {
    fontSize: 14,
    color: "#666",
    marginTop: 4,
  },
  newRequestButton: {
    flexDirection: "row",
    backgroundColor: "#2563eb",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
    alignItems: "center",
  },
  newRequestButtonText: {
    color: "#fff",
    marginLeft: 4,
    fontWeight: "500",
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 8,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  cardContent: {
    padding: 16,
  },
  cardHeader: {
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
  },
  cardSubtitle: {
    fontSize: 14,
    color: "#666",
    marginTop: 2,
  },
  cardDetails: {
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  detailText: {
    fontSize: 14,
    color: "#666",
    marginLeft: 8,
  },
  positionsContainer: {
    marginBottom: 12,
  },
  positionsLabel: {
    fontSize: 14,
    fontWeight: "600",
    marginBottom: 6,
  },
  positionTags: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  positionTag: {
    backgroundColor: "rgba(37, 99, 235, 0.1)",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 6,
    marginBottom: 6,
  },
  positionTagText: {
    color: "#2563eb",
    fontSize: 12,
    fontWeight: "500",
  },
  applyButton: {
    backgroundColor: "#2563eb",
    borderRadius: 6,
    paddingVertical: 10,
    alignItems: "center",
  },
  applyButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  editButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 6,
    paddingVertical: 8,
    alignItems: "center",
    marginRight: 8,
  },
  editButtonText: {
    color: "#666",
  },
  viewButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 6,
    paddingVertical: 8,
    alignItems: "center",
    marginLeft: 8,
  },
  viewButtonText: {
    color: "#666",
  },
  availabilityContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 12,
  },
  dayButton: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginRight: 8,
    marginBottom: 8,
  },
  dayButtonText: {
    color: "#666",
  },
  updateButton: {
    backgroundColor: "#2563eb",
    borderRadius: 6,
    paddingVertical: 10,
    alignItems: "center",
  },
  updateButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
  emptyState: {
    padding: 30,
    alignItems: "center",
  },
  emptyStateText: {
    color: "#666",
    marginBottom: 16,
  },
  createButton: {
    flexDirection: "row",
    backgroundColor: "#2563eb",
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 6,
    alignItems: "center",
  },
  createButtonIcon: {
    marginRight: 6,
  },
  createButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
  teamCard: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  teamInfo: {
    flex: 1,
  },
  teamName: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 4,
  },
  teamLeague: {
    fontSize: 14,
    color: "#666",
    marginBottom: 4,
  },
  teamButtons: {
    alignItems: "flex-end",
  },
  manageButton: {
    backgroundColor: "#2563eb",
    borderRadius: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginBottom: 8,
    width: 120,
    alignItems: "center",
  },
  manageButtonText: {
    color: "#fff",
    fontWeight: "500",
  },
  requestButton: {
    borderWidth: 1,
    borderColor: "#2563eb",
    borderRadius: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    width: 120,
    alignItems: "center",
  },
  requestButtonText: {
    color: "#2563eb",
    fontWeight: "500",
  },
})
