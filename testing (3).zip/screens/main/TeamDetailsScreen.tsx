"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
  FlatList,
} from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import * as LeagueService from "../../services/leagueService"

export default function TeamDetailsScreen({ route, navigation }) {
  const { teamId, league } = route.params
  const [isLoading, setIsLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [team, setTeam] = useState(null)
  const [players, setPlayers] = useState([])
  const [games, setGames] = useState([])
  const [activeTab, setActiveTab] = useState("roster")

  useEffect(() => {
    loadTeamData()
  }, [])

  const loadTeamData = async () => {
    setIsLoading(true)
    try {
      // In a real app, we'd fetch the specific team by ID
      const teams = await LeagueService.getTeams(league)
      const currentTeam = teams.find((t) => t.id === teamId)
      setTeam(currentTeam)

      // Load players and schedule
      const teamPlayers = await LeagueService.getTeamPlayers(league, teamId)
      const teamGames = await LeagueService.getTeamSchedule(league, teamId)

      setPlayers(teamPlayers)
      setGames(teamGames)
    } catch (error) {
      Alert.alert("Error", `Failed to load team data: ${error.message}`)
    } finally {
      setIsLoading(false)
      setRefreshing(false)
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    loadTeamData()
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatTime = (timeString) => {
    if (!timeString) return ""
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    return `${hour > 12 ? hour - 12 : hour}:${minutes} ${hour >= 12 ? "PM" : "AM"}`
  }

  const createSubRequest = (game) => {
    navigation.navigate("RequestSub", {
      prefill: {
        teamName: team?.name,
        gameDate: game.date,
        gameTime: game.time,
        location: game.location,
      },
    })
  }

  if (isLoading && !team) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2563eb" />
        <Text style={styles.loadingText}>Loading team details...</Text>
      </View>
    )
  }

  return (
    <SafeAreaView style={styles.container} edges={["bottom"]}>
      <View style={styles.header}>
        <Text style={styles.title}>{team?.name}</Text>
        <Text style={styles.subtitle}>
          {league} - {team?.division}
        </Text>
      </View>

      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "roster" && styles.activeTab]}
          onPress={() => setActiveTab("roster")}
        >
          <Text style={[styles.tabText, activeTab === "roster" && styles.activeTabText]}>Team Roster</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === "schedule" && styles.activeTab]}
          onPress={() => setActiveTab("schedule")}
        >
          <Text style={[styles.tabText, activeTab === "schedule" && styles.activeTabText]}>Schedule</Text>
        </TouchableOpacity>
      </View>

      {activeTab === "roster" ? (
        <FlatList
          data={players}
          keyExtractor={(item) => item.id}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateText}>No players found for this team.</Text>
            </View>
          }
          renderItem={({ item }) => (
            <View style={styles.playerCard}>
              <View style={styles.playerInfo}>
                <Text style={styles.playerName}>{item.name}</Text>
                <Text style={styles.playerPosition}>{item.position}</Text>
              </View>
              {item.jerseyNumber && (
                <View style={styles.jerseyNumber}>
                  <Text style={styles.jerseyNumberText}>{item.jerseyNumber}</Text>
                </View>
              )}
            </View>
          )}
        />
      ) : (
        <FlatList
          data={games}
          keyExtractor={(item) => item.id}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateText}>No upcoming games found for this team.</Text>
            </View>
          }
          renderItem={({ item }) => (
            <View style={styles.gameCard}>
              <View style={styles.gameInfo}>
                <Text style={styles.gameDate}>{formatDate(item.date)}</Text>
                <Text style={styles.gameTime}>{formatTime(item.time)}</Text>
                <Text style={styles.gameLocation}>{item.location}</Text>
                <View style={styles.gameTeams}>
                  <Text style={styles.gameTeamText}>
                    {item.homeTeamId === teamId ? "vs " : "@ "}
                    {item.homeTeamId === teamId ? item.awayTeamId : item.homeTeamId}
                  </Text>
                </View>
              </View>
              <TouchableOpacity style={styles.requestSubButton} onPress={() => createSubRequest(item)}>
                <Text style={styles.requestSubButtonText}>Request Sub</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: "#666",
  },
  header: {
    padding: 16,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  subtitle: {
    fontSize: 16,
    color: "#666",
    marginTop: 4,
  },
  tabContainer: {
    flexDirection: "row",
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
  },
  tab: {
    flex: 1,
    paddingVertical: 15,
    alignItems: "center",
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: "#2563eb",
  },
  tabText: {
    fontSize: 16,
    color: "#666",
  },
  activeTabText: {
    color: "#2563eb",
    fontWeight: "600",
  },
  emptyState: {
    padding: 40,
    alignItems: "center",
  },
  emptyStateText: {
    color: "#666",
  },
  playerCard: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginHorizontal: 16,
    marginTop: 8,
    marginBottom: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  playerInfo: {
    flex: 1,
  },
  playerName: {
    fontSize: 16,
    fontWeight: "bold",
  },
  playerPosition: {
    fontSize: 14,
    color: "#666",
    marginTop: 2,
  },
  jerseyNumber: {
    backgroundColor: "#2563eb",
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  jerseyNumberText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
  gameCard: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginHorizontal: 16,
    marginTop: 8,
    marginBottom: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  gameInfo: {
    marginBottom: 12,
  },
  gameDate: {
    fontSize: 16,
    fontWeight: "bold",
  },
  gameTime: {
    fontSize: 14,
    color: "#666",
    marginTop: 2,
  },
  gameLocation: {
    fontSize: 14,
    color: "#666",
    marginTop: 2,
  },
  gameTeams: {
    marginTop: 8,
  },
  gameTeamText: {
    fontSize: 15,
    fontWeight: "500",
  },
  requestSubButton: {
    backgroundColor: "#2563eb",
    borderRadius: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignSelf: "flex-start",
  },
  requestSubButtonText: {
    color: "#fff",
    fontWeight: "500",
    fontSize: 14,
  },
})
