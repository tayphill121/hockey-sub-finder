"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { Ionicons } from "@expo/vector-icons"
import * as LeagueService from "../../services/leagueService"

export default function LeagueIntegrationScreen({ navigation }) {
  const [isLoading, setIsLoading] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [ccrhlTeams, setCcrhlTeams] = useState([])
  const [wrhlTeams, setWrhlTeams] = useState([])
  const [selectedLeague, setSelectedLeague] = useState<"CCRHL" | "WRHL">("CCRHL")

  useEffect(() => {
    loadLeagueData()
  }, [selectedLeague])

  const loadLeagueData = async () => {
    setIsLoading(true)
    try {
      if (selectedLeague === "CCRHL") {
        const teams = await LeagueService.getTeams("CCRHL")
        setCcrhlTeams(teams)
      } else {
        const teams = await LeagueService.getTeams("WRHL")
        setWrhlTeams(teams)
      }
    } catch (error) {
      Alert.alert("Error", `Failed to load ${selectedLeague} data: ${error.message}`)
    } finally {
      setIsLoading(false)
      setRefreshing(false)
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    loadLeagueData()
  }

  const importLeagueData = async () => {
    setIsLoading(true)
    try {
      const result = await LeagueService.importLeagueData(selectedLeague)
      if (result.success) {
        Alert.alert("Success", `Successfully imported ${result.teamsImported} teams from ${selectedLeague}`)
      } else {
        Alert.alert("Error", `Import failed: ${result.error}`)
      }
    } catch (error) {
      Alert.alert("Error", `Import failed: ${error.message}`)
    } finally {
      setIsLoading(false)
    }
  }

  const viewTeamDetails = (teamId) => {
    navigation.navigate("TeamDetails", {
      teamId,
      league: selectedLeague,
    })
  }

  return (
    <SafeAreaView style={styles.container} edges={["bottom"]}>
      <View style={styles.header}>
        <Text style={styles.title}>League Integration</Text>
        <Text style={styles.subtitle}>Connect with {selectedLeague} league data</Text>
      </View>

      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, selectedLeague === "CCRHL" && styles.activeTab]}
          onPress={() => setSelectedLeague("CCRHL")}
        >
          <Text style={[styles.tabText, selectedLeague === "CCRHL" && styles.activeTabText]}>CCRHL</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, selectedLeague === "WRHL" && styles.activeTab]}
          onPress={() => setSelectedLeague("WRHL")}
        >
          <Text style={[styles.tabText, selectedLeague === "WRHL" && styles.activeTabText]}>WRHL</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <View style={styles.actionCard}>
          <Text style={styles.actionTitle}>Import League Data</Text>
          <Text style={styles.actionDescription}>
            Import teams, players, and schedules from {selectedLeague} into Hockey Sub Finder.
          </Text>
          <TouchableOpacity style={styles.actionButton} onPress={importLeagueData} disabled={isLoading}>
            {isLoading ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text style={styles.actionButtonText}>Import Now</Text>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{selectedLeague} Teams</Text>
        </View>

        {isLoading && !refreshing ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#2563eb" />
            <Text style={styles.loadingText}>Loading teams...</Text>
          </View>
        ) : (
          <View style={styles.teamsList}>
            {(selectedLeague === "CCRHL" ? ccrhlTeams : wrhlTeams).map((team) => (
              <TouchableOpacity key={team.id} style={styles.teamCard} onPress={() => viewTeamDetails(team.id)}>
                <View style={styles.teamInfo}>
                  <Text style={styles.teamName}>{team.name}</Text>
                  <Text style={styles.teamDivision}>{team.division}</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#666" />
              </TouchableOpacity>
            ))}

            {(selectedLeague === "CCRHL" ? ccrhlTeams : wrhlTeams).length === 0 && !isLoading && (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateText}>No teams found. Pull down to refresh.</Text>
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    padding: 16,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  subtitle: {
    fontSize: 16,
    color: "#666",
    marginTop: 4,
  },
  tabContainer: {
    flexDirection: "row",
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e5e5",
  },
  tab: {
    flex: 1,
    paddingVertical: 15,
    alignItems: "center",
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: "#2563eb",
  },
  tabText: {
    fontSize: 16,
    color: "#666",
  },
  activeTabText: {
    color: "#2563eb",
    fontWeight: "600",
  },
  scrollContent: {
    padding: 16,
  },
  actionCard: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  actionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 8,
  },
  actionDescription: {
    fontSize: 14,
    color: "#666",
    marginBottom: 16,
  },
  actionButton: {
    backgroundColor: "#2563eb",
    borderRadius: 6,
    paddingVertical: 10,
    alignItems: "center",
  },
  actionButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
  sectionHeader: {
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
  },
  loadingContainer: {
    padding: 40,
    alignItems: "center",
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: "#666",
  },
  teamsList: {
    marginBottom: 20,
  },
  teamCard: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginBottom: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  teamInfo: {
    flex: 1,
  },
  teamName: {
    fontSize: 16,
    fontWeight: "bold",
  },
  teamDivision: {
    fontSize: 14,
    color: "#666",
    marginTop: 2,
  },
  emptyState: {
    padding: 40,
    alignItems: "center",
  },
  emptyStateText: {
    color: "#666",
  },
})
