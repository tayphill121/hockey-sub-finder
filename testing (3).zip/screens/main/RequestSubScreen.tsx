"use client"

import { useState } from "react"
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Switch,
} from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useNavigation, useRoute } from "@react-navigation/native"
import { createSubRequest } from "../../services/subRequestService"

export default function RequestSubScreen() {
  const navigation = useNavigation()
  const route = useRoute()
  const prefill = route.params?.prefill

  const [isLoading, setIsLoading] = useState(false)
  const [teamName, setTeamName] = useState(prefill?.teamName || "")
  const [gameDate, setGameDate] = useState(prefill?.gameDate || "")
  const [gameTime, setGameTime] = useState(prefill?.gameTime || "")
  const [location, setLocation] = useState(prefill?.location || "")
  const [positions, setPositions] = useState({
    forward: false,
    defense: false,
    goalie: false,
  })
  const [description, setDescription] = useState("")

  const handlePositionToggle = (position) => {
    setPositions((prev) => ({
      ...prev,
      [position]: !prev[position],
    }))
  }

  const handleSubmit = async () => {
    // Validate form
    if (!teamName || !gameDate || !gameTime || !location) {
      Alert.alert("Error", "Please fill in all required fields")
      return
    }

    const selectedPositions = Object.keys(positions).filter((pos) => positions[pos])
    if (selectedPositions.length === 0) {
      Alert.alert("Error", "Please select at least one position")
      return
    }

    setIsLoading(true)
    try {
      const result = await createSubRequest({
        teamName,
        date: gameDate,
        time: gameTime,
        location,
        positionsNeeded: selectedPositions,
        description,
      })

      if (result.success) {
        Alert.alert("Success", "Your sub request has been created", [
          { text: "OK", onPress: () => navigation.goBack() },
        ])
      } else {
        Alert.alert("Error", result.error || "Failed to create sub request")
      }
    } catch (error) {
      Alert.alert("Error", "An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <SafeAreaView style={styles.container} edges={["bottom"]}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.formContainer}>
            <View style={styles.formGroup}>
              <Text style={styles.label}>Team Name *</Text>
              <TextInput
                style={styles.input}
                value={teamName}
                onChangeText={setTeamName}
                placeholder="Enter your team name"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Game Date *</Text>
              <TextInput style={styles.input} value={gameDate} onChangeText={setGameDate} placeholder="YYYY-MM-DD" />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Game Time *</Text>
              <TextInput style={styles.input} value={gameTime} onChangeText={setGameTime} placeholder="HH:MM" />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Location *</Text>
              <TextInput
                style={styles.input}
                value={location}
                onChangeText={setLocation}
                placeholder="Enter the rink or arena name"
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Positions Needed *</Text>
              <Text style={styles.sublabel}>Select all positions you need substitutes for</Text>

              <View style={styles.positionContainer}>
                <View style={styles.positionRow}>
                  <Text style={styles.positionLabel}>Forward</Text>
                  <Switch
                    value={positions.forward}
                    onValueChange={() => handlePositionToggle("forward")}
                    trackColor={{ false: "#d1d5db", true: "#bfdbfe" }}
                    thumbColor={positions.forward ? "#2563eb" : "#f4f4f5"}
                  />
                </View>

                <View style={styles.positionRow}>
                  <Text style={styles.positionLabel}>Defense</Text>
                  <Switch
                    value={positions.defense}
                    onValueChange={() => handlePositionToggle("defense")}
                    trackColor={{ false: "#d1d5db", true: "#bfdbfe" }}
                    thumbColor={positions.defense ? "#2563eb" : "#f4f4f5"}
                  />
                </View>

                <View style={styles.positionRow}>
                  <Text style={styles.positionLabel}>Goalie</Text>
                  <Switch
                    value={positions.goalie}
                    onValueChange={() => handlePositionToggle("goalie")}
                    trackColor={{ false: "#d1d5db", true: "#bfdbfe" }}
                    thumbColor={positions.goalie ? "#2563eb" : "#f4f4f5"}
                  />
                </View>
              </View>
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.label}>Additional Details</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={description}
                onChangeText={setDescription}
                placeholder="Add any additional information about the game or requirements"
                multiline
                numberOfLines={4}
              />
            </View>

            <TouchableOpacity
              style={[styles.submitButton, isLoading && styles.submitButtonDisabled]}
              onPress={handleSubmit}
              disabled={isLoading}
            >
              <Text style={styles.submitButtonText}>{isLoading ? "Creating Request..." : "Create Sub Request"}</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  scrollContent: {
    padding: 16,
  },
  formContainer: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  formGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 8,
  },
  sublabel: {
    fontSize: 14,
    color: "#666",
    marginBottom: 12,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  textArea: {
    height: 100,
    textAlignVertical: "top",
  },
  positionContainer: {
    marginTop: 8,
  },
  positionRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f0f0f0",
  },
  positionLabel: {
    fontSize: 16,
  },
  submitButton: {
    backgroundColor: "#2563eb",
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: "center",
    marginTop: 10,
  },
  submitButtonDisabled: {
    backgroundColor: "#93c5fd",
  },
  submitButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
})
