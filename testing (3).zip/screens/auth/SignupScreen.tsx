"use client"

import { useState } from "react"
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useAuth } from "../../context/AuthContext"

export default function SignupScreen({ navigation }) {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [accountType, setAccountType] = useState("player")
  const [playerType, setPlayerType] = useState("regular")
  const [isLoading, setIsLoading] = useState(false)
  const { signup } = useAuth()

  const handleSignup = async () => {
    if (!name || !email || !password) {
      Alert.alert("Error", "Please fill in all fields")
      return
    }

    if (password.length < 8) {
      Alert.alert("Error", "Password must be at least 8 characters")
      return
    }

    setIsLoading(true)
    try {
      const success = await signup(name, email, password, accountType, playerType)
      if (success) {
        // If goalie, skip payment and go directly to dashboard
        if (accountType === "player" && playerType === "goalie") {
          navigation.navigate("Main")
        } else {
          // For regular players and teams, redirect to payment
          navigation.navigate("Payment")
        }
      } else {
        Alert.alert("Signup Failed", "Email already exists or an error occurred")
      }
    } catch (error) {
      Alert.alert("Error", "An error occurred during signup")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <Text style={styles.title}>Create an account</Text>
            <Text style={styles.subtitle}>Sign up for HockeySubFinder to get started</Text>
          </View>

          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Full Name</Text>
              <TextInput style={styles.input} placeholder="John Smith" value={name} onChangeText={setName} />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={styles.input}
                placeholder="john@example.com"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Password</Text>
              <TextInput
                style={styles.input}
                placeholder="********"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.label}>Account Type</Text>
              <View style={styles.radioContainer}>
                <TouchableOpacity style={styles.radioOption} onPress={() => setAccountType("player")}>
                  <View style={[styles.radioButton, accountType === "player" && styles.radioButtonSelected]}>
                    {accountType === "player" && <View style={styles.radioButtonInner} />}
                  </View>
                  <Text style={styles.radioLabel}>I want to be a substitute player</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.radioOption} onPress={() => setAccountType("team")}>
                  <View style={[styles.radioButton, accountType === "team" && styles.radioButtonSelected]}>
                    {accountType === "team" && <View style={styles.radioButtonInner} />}
                  </View>
                  <Text style={styles.radioLabel}>I want to find substitute players for my team</Text>
                </TouchableOpacity>
              </View>
            </View>

            {accountType === "player" && (
              <View style={styles.inputContainer}>
                <Text style={styles.label}>Player Type</Text>
                <View style={styles.radioContainer}>
                  <TouchableOpacity style={styles.radioOption} onPress={() => setPlayerType("regular")}>
                    <View style={[styles.radioButton, playerType === "regular" && styles.radioButtonSelected]}>
                      {playerType === "regular" && <View style={styles.radioButtonInner} />}
                    </View>
                    <Text style={styles.radioLabel}>Regular Player ($25/season)</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={styles.radioOption} onPress={() => setPlayerType("goalie")}>
                    <View style={[styles.radioButton, playerType === "goalie" && styles.radioButtonSelected]}>
                      {playerType === "goalie" && <View style={styles.radioButtonInner} />}
                    </View>
                    <Text style={styles.radioLabel}>Goalie (Free)</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}

            <TouchableOpacity
              style={[styles.button, isLoading && styles.buttonDisabled]}
              onPress={handleSignup}
              disabled={isLoading}
            >
              <Text style={styles.buttonText}>{isLoading ? "Creating account..." : "Create account"}</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.footer}>
            <Text style={styles.termsText}>
              By creating an account, you agree to our <Text style={styles.termsLink}>Terms of Service</Text> and{" "}
              <Text style={styles.termsLink}>Privacy Policy</Text>.
            </Text>
            <Text style={styles.footerText}>
              Already have an account?{" "}
              <Text style={styles.footerLink} onPress={() => navigation.navigate("Login")}>
                Log in
              </Text>
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  scrollContent: {
    flexGrow: 1,
    padding: 20,
  },
  header: {
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: "#666",
  },
  form: {
    marginBottom: 30,
  },
  inputContainer: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: "500",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  radioContainer: {
    marginTop: 8,
  },
  radioOption: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  radioButton: {
    height: 20,
    width: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: "#ddd",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10,
  },
  radioButtonSelected: {
    borderColor: "#2563eb",
  },
  radioButtonInner: {
    height: 10,
    width: 10,
    borderRadius: 5,
    backgroundColor: "#2563eb",
  },
  radioLabel: {
    fontSize: 16,
    flex: 1,
  },
  button: {
    backgroundColor: "#2563eb",
    borderRadius: 8,
    padding: 15,
    alignItems: "center",
    marginTop: 10,
  },
  buttonDisabled: {
    backgroundColor: "#93c5fd",
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
  footer: {
    marginTop: "auto",
    alignItems: "center",
  },
  termsText: {
    fontSize: 14,
    color: "#666",
    textAlign: "center",
    marginBottom: 15,
  },
  termsLink: {
    color: "#2563eb",
  },
  footerText: {
    fontSize: 16,
    color: "#666",
  },
  footerLink: {
    color: "#2563eb",
    fontWeight: "600",
  },
})
