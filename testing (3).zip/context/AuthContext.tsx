"use client"

import type React from "react"
import { createContext, useState, useContext, useEffect } from "react"
import AsyncStorage from "@react-native-async-storage/async-storage"

type User = {
  id: string
  name: string
  email: string
  role: "player" | "team"
  playerType?: "regular" | "goalie"
  isPaid: boolean
}

type AuthContextType = {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<boolean>
  signup: (
    name: string,
    email: string,
    password: string,
    role: "player" | "team",
    playerType?: "regular" | "goalie",
  ) => Promise<boolean>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Demo users for testing
const demoUsers = [
  {
    id: "1",
    name: "Demo User",
    email: "user@example.com",
    password: "password",
    role: "player",
    playerType: "regular",
    isPaid: true,
  },
  {
    id: "2",
    name: "Team Manager",
    email: "manager@example.com",
    password: "password",
    role: "team",
    isPaid: true,
  },
  {
    id: "3",
    name: "Demo Goalie",
    email: "goalie@example.com",
    password: "password",
    role: "player",
    playerType: "goalie",
    isPaid: true, // Goalies are automatically paid
  },
]

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    const loadUser = async () => {
      try {
        const userJson = await AsyncStorage.getItem("@user")
        if (userJson) {
          setUser(JSON.parse(userJson))
        }
      } catch (e) {
        console.error("Failed to load user from storage", e)
      } finally {
        setIsLoading(false)
      }
    }

    loadUser()
  }, [])

  const login = async (email: string, password: string) => {
    try {
      // In a real app, this would be an API call
      const user = demoUsers.find((u) => u.email === email && u.password === password)

      if (!user) {
        return false
      }

      const { password: _, ...userWithoutPassword } = user
      setUser(userWithoutPassword)
      await AsyncStorage.setItem("@user", JSON.stringify(userWithoutPassword))
      return true
    } catch (e) {
      console.error("Login error", e)
      return false
    }
  }

  const signup = async (
    name: string,
    email: string,
    password: string,
    role: "player" | "team",
    playerType?: "regular" | "goalie",
  ) => {
    try {
      // In a real app, this would be an API call
      if (demoUsers.some((u) => u.email === email)) {
        return false
      }

      const newUser = {
        id: (demoUsers.length + 1).toString(),
        name,
        email,
        password,
        role,
        playerType: role === "player" ? playerType : undefined,
        // Goalies are automatically paid
        isPaid: role === "player" && playerType === "goalie",
      }

      demoUsers.push(newUser)

      const { password: _, ...userWithoutPassword } = newUser
      setUser(userWithoutPassword)
      await AsyncStorage.setItem("@user", JSON.stringify(userWithoutPassword))
      return true
    } catch (e) {
      console.error("Signup error", e)
      return false
    }
  }

  const logout = async () => {
    try {
      await AsyncStorage.removeItem("@user")
      setUser(null)
    } catch (e) {
      console.error("Logout error", e)
    }
  }

  return <AuthContext.Provider value={{ user, isLoading, login, signup, logout }}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
