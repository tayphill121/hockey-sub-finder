// Mock data for demonstration
const subRequests = [
  {
    id: "1",
    teamName: "Maple Leafs",
    date: "2025-05-10",
    time: "19:00",
    location: "City Ice Arena",
    positionsNeeded: ["forward", "defense"],
    description: "Regular season game, need 2 subs.",
    createdAt: "2025-04-23T12:00:00Z",
  },
  {
    id: "2",
    teamName: "Bruins",
    date: "2025-05-15",
    time: "20:30",
    location: "Community Rink",
    positionsNeeded: ["goalie"],
    description: "Our regular goalie is out of town.",
    createdAt: "2025-04-24T14:30:00Z",
  },
]

export async function getSubRequests() {
  // In a real app, this would fetch from an API
  return subRequests
}

export async function createSubRequest(data: {
  teamName: string
  date: string
  time: string
  location: string
  positionsNeeded: string[]
  description: string
}) {
  try {
    // Validate required fields
    if (!data.teamName || !data.date || !data.time || !data.location || !data.positionsNeeded.length) {
      return { error: "Missing required fields" }
    }

    // Create new request
    const newRequest = {
      id: (subRequests.length + 1).toString(),
      ...data,
      createdAt: new Date().toISOString(),
    }

    // Add to our "database"
    subRequests.push(newRequest)

    return { success: true, request: newRequest }
  } catch (error) {
    console.error("Error creating sub request:", error)
    return { error: "Failed to create sub request" }
  }
}
