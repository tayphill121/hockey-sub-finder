// Notification service for sending emails and texts to players

interface SubRequest {
  id: string
  teamName: string
  date: string
  time: string
  location: string
  requestType: "open" | "targeted"
  positionsNeeded: string[]
  selectedPlayers: string[]
  description: string
  urgency: "normal" | "urgent"
  responseDeadline: number
  status: string
  responses: Array<{
    playerId: string
    response: "accept" | "decline"
    timestamp: string
  }>
  createdAt: string
}

// Mock function to simulate sending an email
async function sendEmail(to: string, subject: string, body: string): Promise<boolean> {
  console.log(`Sending email to ${to}:`)
  console.log(`Subject: ${subject}`)
  console.log(`Body: ${body}`)

  // In a real app, you would use a service like SendGrid, AWS SES, etc.
  // For demo purposes, we'll just return true
  return true
}

// Mock function to simulate sending a text message
async function sendSMS(to: string, message: string): Promise<boolean> {
  console.log(`Sending SMS to ${to}:`)
  console.log(`Message: ${message}`)

  // In a real app, you would use a service like Twilio, AWS SNS, etc.
  // For demo purposes, we'll just return true
  return true
}

// Function to get players that match the positions needed
async function getMatchingPlayers(positionsNeeded: string[]): Promise<any[]> {
  // In a real app, you would query your database
  // For demo purposes, we'll return some mock data
  const allPlayers = [
    { id: "player1", name: "John Smith", email: "john@example.com", phone: "555-1234", position: "forward" },
    { id: "player2", name: "Sarah Johnson", email: "sarah@example.com", phone: "555-2345", position: "defense" },
    { id: "player3", name: "Mike Wilson", email: "mike@example.com", phone: "555-3456", position: "goalie" },
    { id: "player4", name: "Emma Brown", email: "emma@example.com", phone: "555-4567", position: "forward" },
    { id: "player5", name: "David Lee", email: "david@example.com", phone: "555-5678", position: "defense" },
  ]

  return allPlayers.filter((player) => positionsNeeded.includes(player.position))
}

// Function to get player details by ID
async function getPlayerById(playerId: string): Promise<any> {
  // In a real app, you would query your database
  // For demo purposes, we'll return some mock data
  const allPlayers = [
    { id: "player1", name: "John Smith", email: "john@example.com", phone: "555-1234", position: "forward" },
    { id: "player2", name: "Sarah Johnson", email: "sarah@example.com", phone: "555-2345", position: "defense" },
    { id: "player3", name: "Mike Wilson", email: "mike@example.com", phone: "555-3456", position: "goalie" },
    { id: "player4", name: "Emma Brown", email: "emma@example.com", phone: "555-4567", position: "forward" },
    { id: "player5", name: "David Lee", email: "david@example.com", phone: "555-5678", position: "defense" },
  ]

  return allPlayers.find((player) => player.id === playerId)
}

// Format date for display
function formatDate(dateString: string): string {
  const date = new Date(dateString)
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

// Format time for display
function formatTime(timeString: string): string {
  const [hours, minutes] = timeString.split(":")
  const hour = Number.parseInt(hours)
  return `${hour > 12 ? hour - 12 : hour}:${minutes} ${hour >= 12 ? "PM" : "AM"}`
}

// Main function to send notifications for a sub request
export async function sendNotifications(request: SubRequest): Promise<void> {
  try {
    if (request.requestType === "open") {
      // For open requests, send to all matching players
      const matchingPlayers = await getMatchingPlayers(request.positionsNeeded)

      for (const player of matchingPlayers) {
        // Create response URL with token
        const acceptUrl = `https://hockeysubfinder.com/respond/${request.id}/${player.id}/accept`
        const declineUrl = `https://hockeysubfinder.com/respond/${request.id}/${player.id}/decline`

        // Email subject and body
        const subject = `Hockey Sub Request: ${request.teamName} needs a ${player.position}`
        const body = `
          Hi ${player.name},

          ${request.teamName} is looking for a ${player.position} for their game on ${formatDate(request.date)} at ${formatTime(request.time)}.
          
          Location: ${request.location}
          
          ${request.description ? `Additional details: ${request.description}` : ""}
          
          Please respond within ${request.responseDeadline} hours by clicking one of the links below:
          
          Accept: ${acceptUrl}
          Decline: ${declineUrl}
          
          Thank you!
          Hockey Sub Finder
        `

        // Send email
        await sendEmail(player.email, subject, body)

        // Send SMS for urgent requests
        if (request.urgency === "urgent") {
          const smsMessage = `URGENT: ${request.teamName} needs a ${player.position} on ${formatDate(request.date)} at ${formatTime(request.time)}. Reply at ${acceptUrl}`
          await sendSMS(player.phone, smsMessage)
        }
      }
    } else if (request.requestType === "targeted") {
      // For targeted requests, send to the first player in the list
      if (request.selectedPlayers.length > 0) {
        const firstPlayerId = request.selectedPlayers[0]
        const player = await getPlayerById(firstPlayerId)

        if (player) {
          // Create response URL with token
          const acceptUrl = `https://hockeysubfinder.com/respond/${request.id}/${player.id}/accept`
          const declineUrl = `https://hockeysubfinder.com/respond/${request.id}/${player.id}/decline`

          // Email subject and body
          const subject = `Hockey Sub Request: ${request.teamName} needs you as a ${player.position}`
          const body = `
            Hi ${player.name},
            
            ${request.teamName} has specifically requested you as a ${player.position} for their game on ${formatDate(request.date)} at ${formatTime(request.time)}.
            
            Location: ${request.location}
            
            ${request.description ? `Additional details: ${request.description}` : ""}
            
            Please respond within ${request.responseDeadline} hours by clicking one of the links below:
            
            Accept: ${acceptUrl}
            Decline: ${declineUrl}
            
            Thank you!
            Hockey Sub Finder
          `

          // Send email
          await sendEmail(player.email, subject, body)

          // Send SMS for urgent requests
          if (request.urgency === "urgent") {
            const smsMessage = `URGENT: ${request.teamName} specifically requested you as a ${player.position} on ${formatDate(request.date)}. Reply at ${acceptUrl}`
            await sendSMS(player.phone, smsMessage)
          }
        }
      }
    }
  } catch (error) {
    console.error("Error sending notifications:", error)
    throw error
  }
}

// Function to send notification to the next player in the list
export async function notifyNextPlayer(request: SubRequest): Promise<void> {
  try {
    if (request.requestType === "targeted" && request.status !== "filled") {
      // Get the players who have already responded
      const respondedPlayerIds = request.responses.map((r) => r.playerId)

      // Find the next player who hasn't responded yet
      const nextPlayerId = request.selectedPlayers.find((id) => !respondedPlayerIds.includes(id))

      if (nextPlayerId) {
        const player = await getPlayerById(nextPlayerId)

        if (player) {
          // Create response URL with token
          const acceptUrl = `https://hockeysubfinder.com/respond/${request.id}/${player.id}/accept`
          const declineUrl = `https://hockeysubfinder.com/respond/${request.id}/${player.id}/decline`

          // Email subject and body
          const subject = `Hockey Sub Request: ${request.teamName} needs you as a ${player.position}`
          const body = `
            Hi ${player.name},
            
            ${request.teamName} has requested you as a ${player.position} for their game on ${formatDate(request.date)} at ${formatTime(request.time)}.
            
            Location: ${request.location}
            
            ${request.description ? `Additional details: ${request.description}` : ""}
            
            Please respond within ${request.responseDeadline} hours by clicking one of the links below:
            
            Accept: ${acceptUrl}
            Decline: ${declineUrl}
            
            Thank you!
            Hockey Sub Finder
          `

          // Send email
          await sendEmail(player.email, subject, body)

          // Send SMS for urgent requests
          if (request.urgency === "urgent") {
            const smsMessage = `URGENT: ${request.teamName} needs you as a ${player.position} on ${formatDate(request.date)}. Reply at ${acceptUrl}`
            await sendSMS(player.phone, smsMessage)
          }
        }
      }
    }
  } catch (error) {
    console.error("Error notifying next player:", error)
    throw error
  }
}

// Schedule notifications for deadline reminders
export async function scheduleDeadlineReminders(request: SubRequest): Promise<void> {
  // In a real app, you would use a job scheduler like Bull, Agenda, etc.
  // For demo purposes, we'll just log that we would schedule reminders
  console.log(`Scheduling deadline reminders for request ${request.id}`)
  console.log(`Deadline: ${request.responseDeadline} hours`)
}
