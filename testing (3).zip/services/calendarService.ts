// Calendar integration service for managing player availability

// Types for calendar events and availability
export interface CalendarEvent {
  id: string
  title: string
  start: Date
  end: Date
  allDay?: boolean
  location?: string
  description?: string
  source?: "manual" | "google" | "apple" | "outlook"
}

export interface RecurringAvailability {
  id: string
  dayOfWeek: 0 | 1 | 2 | 3 | 4 | 5 | 6 // 0 = Sunday, 1 = Monday, etc.
  startTime: string // HH:MM format
  endTime: string // HH:MM format
  isAvailable: boolean
}

export interface BlackoutDate {
  id: string
  date: Date
  reason?: string
}

// Mock data for demonstration
const userCalendarEvents: Record<string, CalendarEvent[]> = {
  user1: [
    {
      id: "evt1",
      title: "Hockey Practice",
      start: new Date(2025, 4, 10, 19, 0),
      end: new Date(2025, 4, 10, 20, 30),
      location: "City Ice Arena",
      source: "manual",
    },
    {
      id: "evt2",
      title: "League Game",
      start: new Date(2025, 4, 15, 20, 0),
      end: new Date(2025, 4, 15, 21, 30),
      location: "Community Rink",
      source: "manual",
    },
  ],
}

const userRecurringAvailability: Record<string, RecurringAvailability[]> = {
  user1: [
    {
      id: "rec1",
      dayOfWeek: 1, // Monday
      startTime: "18:00",
      endTime: "22:00",
      isAvailable: true,
    },
    {
      id: "rec2",
      dayOfWeek: 3, // Wednesday
      startTime: "18:00",
      endTime: "22:00",
      isAvailable: true,
    },
    {
      id: "rec3",
      dayOfWeek: 5, // Friday
      startTime: "18:00",
      endTime: "22:00",
      isAvailable: true,
    },
  ],
}

const userBlackoutDates: Record<string, BlackoutDate[]> = {
  user1: [
    {
      id: "bd1",
      date: new Date(2025, 4, 20),
      reason: "Family vacation",
    },
    {
      id: "bd2",
      date: new Date(2025, 4, 21),
      reason: "Family vacation",
    },
  ],
}

// Get all calendar events for a user
export async function getUserCalendarEvents(userId: string): Promise<CalendarEvent[]> {
  return userCalendarEvents[userId] || []
}

// Add a calendar event for a user
export async function addCalendarEvent(userId: string, event: Omit<CalendarEvent, "id">): Promise<CalendarEvent> {
  const newEvent = {
    ...event,
    id: `evt${Date.now()}`,
  }

  if (!userCalendarEvents[userId]) {
    userCalendarEvents[userId] = []
  }

  userCalendarEvents[userId].push(newEvent)
  return newEvent
}

// Update a calendar event
export async function updateCalendarEvent(userId: string, event: CalendarEvent): Promise<CalendarEvent> {
  if (!userCalendarEvents[userId]) return null

  const index = userCalendarEvents[userId].findIndex((e) => e.id === event.id)
  if (index === -1) return null

  userCalendarEvents[userId][index] = event
  return event
}

// Delete a calendar event
export async function deleteCalendarEvent(userId: string, eventId: string): Promise<boolean> {
  if (!userCalendarEvents[userId]) return false

  const initialLength = userCalendarEvents[userId].length
  userCalendarEvents[userId] = userCalendarEvents[userId].filter((e) => e.id !== eventId)

  return userCalendarEvents[userId].length < initialLength
}

// Get recurring availability for a user
export async function getUserRecurringAvailability(userId: string): Promise<RecurringAvailability[]> {
  return userRecurringAvailability[userId] || []
}

// Update recurring availability for a user
export async function updateRecurringAvailability(
  userId: string,
  availability: RecurringAvailability[],
): Promise<RecurringAvailability[]> {
  userRecurringAvailability[userId] = availability
  return availability
}

// Get blackout dates for a user
export async function getUserBlackoutDates(userId: string): Promise<BlackoutDate[]> {
  return userBlackoutDates[userId] || []
}

// Add a blackout date for a user
export async function addBlackoutDate(userId: string, blackout: Omit<BlackoutDate, "id">): Promise<BlackoutDate> {
  const newBlackout = {
    ...blackout,
    id: `bd${Date.now()}`,
  }

  if (!userBlackoutDates[userId]) {
    userBlackoutDates[userId] = []
  }

  userBlackoutDates[userId].push(newBlackout)
  return newBlackout
}

// Delete a blackout date
export async function deleteBlackoutDate(userId: string, blackoutId: string): Promise<boolean> {
  if (!userBlackoutDates[userId]) return false

  const initialLength = userBlackoutDates[userId].length
  userBlackoutDates[userId] = userBlackoutDates[userId].filter((b) => b.id !== blackoutId)

  return userBlackoutDates[userId].length < initialLength
}

// Check if a user is available at a specific time
export async function checkUserAvailability(userId: string, start: Date, end: Date): Promise<boolean> {
  // 1. Check if the date is a blackout date
  const blackoutDates = await getUserBlackoutDates(userId)
  const isBlackout = blackoutDates.some((blackout) => {
    const blackoutDate = new Date(blackout.date)
    return (
      blackoutDate.getFullYear() === start.getFullYear() &&
      blackoutDate.getMonth() === start.getMonth() &&
      blackoutDate.getDate() === start.getDate()
    )
  })

  if (isBlackout) return false

  // 2. Check if there's a conflicting event
  const events = await getUserCalendarEvents(userId)
  const hasConflict = events.some((event) => {
    return start < event.end && end > event.start
  })

  if (hasConflict) return false

  // 3. Check recurring availability
  const dayOfWeek = start.getDay() as 0 | 1 | 2 | 3 | 4 | 5 | 6
  const startHours = start.getHours()
  const startMinutes = start.getMinutes()
  const startTimeString = `${startHours.toString().padStart(2, "0")}:${startMinutes.toString().padStart(2, "0")}`

  const endHours = end.getHours()
  const endMinutes = end.getMinutes()
  const endTimeString = `${endHours.toString().padStart(2, "0")}:${endMinutes.toString().padStart(2, "0")}`

  const recurringAvailability = await getUserRecurringAvailability(userId)
  const matchingAvailability = recurringAvailability.find((a) => a.dayOfWeek === dayOfWeek)

  if (!matchingAvailability) return false

  return (
    matchingAvailability.isAvailable &&
    matchingAvailability.startTime <= startTimeString &&
    matchingAvailability.endTime >= endTimeString
  )
}

// Google Calendar Integration

// This would be replaced with actual Google Calendar API integration
export async function connectGoogleCalendar(userId: string, authCode: string): Promise<boolean> {
  console.log(`Connecting Google Calendar for user ${userId} with auth code ${authCode}`)
  // In a real implementation, you would:
  // 1. Exchange the auth code for access and refresh tokens
  // 2. Store the tokens securely
  // 3. Use the tokens to fetch events from Google Calendar

  // For demo purposes, we'll just return true
  return true
}

export async function importGoogleCalendarEvents(userId: string): Promise<CalendarEvent[]> {
  // In a real implementation, you would:
  // 1. Retrieve the user's Google Calendar access token
  // 2. Make API calls to Google Calendar to fetch events
  // 3. Convert the events to our CalendarEvent format
  // 4. Store the events in our database

  // For demo purposes, we'll add some mock events
  const googleEvents: CalendarEvent[] = [
    {
      id: `google-${Date.now()}-1`,
      title: "Hockey Game (Google)",
      start: new Date(2025, 4, 18, 19, 0),
      end: new Date(2025, 4, 18, 20, 30),
      location: "Downtown Arena",
      source: "google",
    },
    {
      id: `google-${Date.now()}-2`,
      title: "Team Practice (Google)",
      start: new Date(2025, 4, 22, 18, 0),
      end: new Date(2025, 4, 22, 19, 30),
      location: "Community Rink",
      source: "google",
    },
  ]

  if (!userCalendarEvents[userId]) {
    userCalendarEvents[userId] = []
  }

  // Add the Google events to the user's calendar
  userCalendarEvents[userId] = [...userCalendarEvents[userId].filter((e) => e.source !== "google"), ...googleEvents]

  return googleEvents
}

// Apple Calendar Integration

export async function connectAppleCalendar(userId: string, authData: any): Promise<boolean> {
  console.log(`Connecting Apple Calendar for user ${userId}`)
  // Implementation would be similar to Google Calendar
  return true
}

// Outlook Calendar Integration

export async function connectOutlookCalendar(userId: string, authData: any): Promise<boolean> {
  console.log(`Connecting Outlook Calendar for user ${userId}`)
  // Implementation would be similar to Google Calendar
  return true
}

// Season Schedule Import

export async function importSeasonSchedule(userId: string, teamId: string, leagueId: string): Promise<CalendarEvent[]> {
  // In a real implementation, you would:
  // 1. Fetch the team's season schedule from the league API
  // 2. Convert the games to CalendarEvent format
  // 3. Add them to the user's calendar

  // For demo purposes, we'll add some mock events
  const seasonEvents: CalendarEvent[] = []

  // Generate 10 weekly games
  const startDate = new Date(2025, 4, 1)
  for (let i = 0; i < 10; i++) {
    const gameDate = new Date(startDate)
    gameDate.setDate(gameDate.getDate() + i * 7) // Weekly games

    seasonEvents.push({
      id: `season-${teamId}-${i}`,
      title: `${teamId} vs Opponent ${i + 1}`,
      start: new Date(gameDate.getFullYear(), gameDate.getMonth(), gameDate.getDate(), 19, 0),
      end: new Date(gameDate.getFullYear(), gameDate.getMonth(), gameDate.getDate(), 20, 30),
      location: "League Arena",
      description: `Regular season game ${i + 1}`,
      source: "manual",
    })
  }

  if (!userCalendarEvents[userId]) {
    userCalendarEvents[userId] = []
  }

  // Add the season events to the user's calendar
  userCalendarEvents[userId] = [...userCalendarEvents[userId], ...seasonEvents]

  return seasonEvents
}
