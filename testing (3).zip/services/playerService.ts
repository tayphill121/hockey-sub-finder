// Player service for managing player data

// Mock data for demonstration
const players = [
  {
    id: "player1",
    name: "John Smith",
    email: "john@example.com",
    phone: "555-1234",
    position: "forward",
    availability: ["Monday", "Wednesday", "Friday"],
    rating: 4.5,
    avatarUrl: "/avatars/john.jpg",
  },
  {
    id: "player2",
    name: "Sarah Johnson",
    email: "sarah@example.com",
    phone: "555-2345",
    position: "defense",
    availability: ["Tuesday", "Thursday", "Saturday"],
    rating: 4.8,
    avatarUrl: "/avatars/sarah.jpg",
  },
  {
    id: "player3",
    name: "Mike Wilson",
    email: "mike@example.com",
    phone: "555-3456",
    position: "goalie",
    availability: ["Monday", "Thursday", "Sunday"],
    rating: 4.9,
    avatarUrl: "/avatars/mike.jpg",
  },
  {
    id: "player4",
    name: "Emma Brown",
    email: "emma@example.com",
    phone: "555-4567",
    position: "forward",
    availability: ["Wednesday", "Friday", "Saturday"],
    rating: 4.2,
    avatarUrl: "/avatars/emma.jpg",
  },
  {
    id: "player5",
    name: "David Lee",
    email: "david@example.com",
    phone: "555-5678",
    position: "defense",
    availability: ["Monday", "Wednesday", "Sunday"],
    rating: 4.7,
    avatarUrl: "/avatars/david.jpg",
  },
  {
    id: "player6",
    name: "Alex Chen",
    email: "alex@example.com",
    phone: "555-6789",
    position: "goalie",
    availability: ["Tuesday", "Friday", "Saturday"],
    rating: 4.6,
    avatarUrl: "/avatars/alex.jpg",
  },
]

// Get all players
export async function getAllPlayers() {
  // In a real app, you would fetch from a database
  return players
}

// Get player by ID
export async function getPlayerById(id: string) {
  // In a real app, you would fetch from a database
  return players.find((player) => player.id === id)
}

// Get players by position
export async function getPlayersByPosition(position: string) {
  // In a real app, you would fetch from a database
  return players.filter((player) => player.position === position)
}

// Get available players based on positions needed
export async function getAvailablePlayers(positionsNeeded: string[]) {
  // In a real app, you would fetch from a database with more complex filtering
  return players.filter((player) => positionsNeeded.includes(player.position))
}

// Update player availability
export async function updatePlayerAvailability(playerId: string, availability: string[]) {
  // In a real app, you would update the database
  const playerIndex = players.findIndex((player) => player.id === playerId)
  if (playerIndex !== -1) {
    players[playerIndex].availability = availability
    return true
  }
  return false
}
