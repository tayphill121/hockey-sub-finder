"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import {
  type RecurringAvailability,
  getUserRecurringAvailability,
  updateRecurringAvailability,
} from "@/services/calendarService"
import { useSession } from "next-auth/react"
import { Loader2 } from "lucide-react"

const daysOfWeek = [
  { value: "0", label: "Sunday" },
  { value: "1", label: "Monday" },
  { value: "2", label: "Tuesday" },
  { value: "3", label: "Wednesday" },
  { value: "4", label: "Thursday" },
  { value: "5", label: "Friday" },
  { value: "6", label: "Saturday" },
]

const timeOptions = Array.from({ length: 24 * 4 }).map((_, i) => {
  const hour = Math.floor(i / 4)
  const minute = (i % 4) * 15
  const ampm = hour < 12 ? "AM" : "PM"
  const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour
  return {
    value: `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`,
    label: `${displayHour}:${minute.toString().padStart(2, "0")} ${ampm}`,
  }
})

export function RecurringAvailabilitySettings() {
  const { data: session } = useSession()
  const [availability, setAvailability] = useState<RecurringAvailability[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    async function loadAvailability() {
      if (session?.user?.id) {
        setIsLoading(true)
        try {
          const userAvailability = await getUserRecurringAvailability(session.user.id)

          // Ensure we have an entry for each day of the week
          const fullAvailability = daysOfWeek.map((day) => {
            const existing = userAvailability.find((a) => a.dayOfWeek === Number.parseInt(day.value))
            return (
              existing || {
                id: `new-${day.value}`,
                dayOfWeek: Number.parseInt(day.value) as 0 | 1 | 2 | 3 | 4 | 5 | 6,
                startTime: "18:00",
                endTime: "22:00",
                isAvailable: false,
              }
            )
          })

          setAvailability(fullAvailability)
        } catch (error) {
          console.error("Error loading availability:", error)
        } finally {
          setIsLoading(false)
        }
      }
    }

    loadAvailability()
  }, [session?.user?.id])

  const handleToggleDay = (dayOfWeek: number) => {
    setAvailability((prev) =>
      prev.map((day) => (day.dayOfWeek === dayOfWeek ? { ...day, isAvailable: !day.isAvailable } : day)),
    )
  }

  const handleTimeChange = (dayOfWeek: number, field: "startTime" | "endTime", value: string) => {
    setAvailability((prev) => prev.map((day) => (day.dayOfWeek === dayOfWeek ? { ...day, [field]: value } : day)))
  }

  const handleSave = async () => {
    if (!session?.user?.id) return

    setIsSaving(true)
    try {
      await updateRecurringAvailability(session.user.id, availability)
      toast({
        title: "Availability updated",
        description: "Your recurring availability has been saved.",
      })
    } catch (error) {
      console.error("Error saving availability:", error)
      toast({
        title: "Error",
        description: "Failed to save your availability. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Recurring Availability</CardTitle>
        <CardDescription>Set your regular weekly availability for hockey games</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {daysOfWeek.map((day) => {
            const dayAvailability = availability.find((a) => a.dayOfWeek === Number.parseInt(day.value))
            if (!dayAvailability) return null

            return (
              <div
                key={day.value}
                className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 sm:items-center"
              >
                <div className="flex items-center space-x-2 w-40">
                  <Switch
                    checked={dayAvailability.isAvailable}
                    onCheckedChange={() => handleToggleDay(Number.parseInt(day.value))}
                  />
                  <Label>{day.label}</Label>
                </div>

                {dayAvailability.isAvailable && (
                  <div className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-2 sm:items-center">
                    <div className="flex items-center space-x-2">
                      <Label>From</Label>
                      <Select
                        value={dayAvailability.startTime}
                        onValueChange={(value) => handleTimeChange(Number.parseInt(day.value), "startTime", value)}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue placeholder="Start time" />
                        </SelectTrigger>
                        <SelectContent>
                          {timeOptions.map((time) => (
                            <SelectItem key={time.value} value={time.value}>
                              {time.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Label>To</Label>
                      <Select
                        value={dayAvailability.endTime}
                        onValueChange={(value) => handleTimeChange(Number.parseInt(day.value), "endTime", value)}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue placeholder="End time" />
                        </SelectTrigger>
                        <SelectContent>
                          {timeOptions.map((time) => (
                            <SelectItem
                              key={time.value}
                              value={time.value}
                              disabled={time.value <= dayAvailability.startTime}
                            >
                              {time.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}
              </div>
            )
          })}

          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              "Save Availability"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
