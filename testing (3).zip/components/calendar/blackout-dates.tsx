"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CalendarIcon, Trash2 } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { toast } from "@/components/ui/use-toast"
import {
  type BlackoutDate,
  getUserBlackoutDates,
  addBlackoutDate,
  deleteBlackoutDate,
} from "@/services/calendarService"
import { useSession } from "next-auth/react"
import { Loader2 } from "lucide-react"

export function BlackoutDatesManager() {
  const { data: session } = useSession()
  const [blackoutDates, setBlackoutDates] = useState<BlackoutDate[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAdding, setIsAdding] = useState(false)
  const [newDate, setNewDate] = useState<Date | undefined>(undefined)
  const [newReason, setNewReason] = useState("")
  const [calendarOpen, setCalendarOpen] = useState(false)

  useEffect(() => {
    async function loadBlackoutDates() {
      if (session?.user?.id) {
        setIsLoading(true)
        try {
          const dates = await getUserBlackoutDates(session.user.id)
          setBlackoutDates(dates)
        } catch (error) {
          console.error("Error loading blackout dates:", error)
        } finally {
          setIsLoading(false)
        }
      }
    }

    loadBlackoutDates()
  }, [session?.user?.id])

  const handleAddBlackoutDate = async () => {
    if (!session?.user?.id || !newDate) return

    setIsAdding(true)
    try {
      const newBlackout = await addBlackoutDate(session.user.id, {
        date: newDate,
        reason: newReason.trim() || undefined,
      })

      setBlackoutDates((prev) => [...prev, newBlackout])
      setNewDate(undefined)
      setNewReason("")
      setCalendarOpen(false)

      toast({
        title: "Blackout date added",
        description: `You've marked ${format(newDate, "PPP")} as unavailable.`,
      })
    } catch (error) {
      console.error("Error adding blackout date:", error)
      toast({
        title: "Error",
        description: "Failed to add blackout date. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsAdding(false)
    }
  }

  const handleDeleteBlackoutDate = async (id: string) => {
    if (!session?.user?.id) return

    try {
      const success = await deleteBlackoutDate(session.user.id, id)
      if (success) {
        setBlackoutDates((prev) => prev.filter((date) => date.id !== id))
        toast({
          title: "Blackout date removed",
          description: "The blackout date has been removed from your calendar.",
        })
      }
    } catch (error) {
      console.error("Error deleting blackout date:", error)
      toast({
        title: "Error",
        description: "Failed to remove blackout date. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Blackout Dates</CardTitle>
        <CardDescription>Mark dates when you're unavailable to play</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
            <div className="flex-1">
              <Label htmlFor="blackout-date">Date</Label>
              <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {newDate ? format(newDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={newDate} onSelect={setNewDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex-1">
              <Label htmlFor="blackout-reason">Reason (optional)</Label>
              <Input
                id="blackout-reason"
                value={newReason}
                onChange={(e) => setNewReason(e.target.value)}
                placeholder="e.g., Family vacation"
              />
            </div>

            <div className="flex items-end">
              <Button onClick={handleAddBlackoutDate} disabled={!newDate || isAdding}>
                {isAdding ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  "Add Date"
                )}
              </Button>
            </div>
          </div>

          {blackoutDates.length > 0 ? (
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Your Blackout Dates</h3>
              <div className="border rounded-md divide-y">
                {blackoutDates.map((blackout) => (
                  <div key={blackout.id} className="flex items-center justify-between p-3">
                    <div>
                      <p className="font-medium">{format(new Date(blackout.date), "PPP")}</p>
                      {blackout.reason && <p className="text-sm text-muted-foreground">{blackout.reason}</p>}
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteBlackoutDate(blackout.id)}>
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Delete</span>
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">You haven't added any blackout dates yet.</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
