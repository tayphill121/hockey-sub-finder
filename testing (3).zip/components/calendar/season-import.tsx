"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { importSeasonSchedule } from "@/services/calendarService"
import { useSession } from "next-auth/react"
import { Loader2 } from "lucide-react"

// Mock data for teams and leagues
const teams = [
  { id: "team1", name: "Maple Leafs" },
  { id: "team2", name: "Bruins" },
  { id: "team3", name: "Flyers" },
]

const leagues = [
  { id: "league1", name: "City League" },
  { id: "league2", name: "CCRHL" },
  { id: "league3", name: "WRHL" },
]

export function SeasonImport() {
  const { data: session } = useSession()
  const [selectedTeam, setSelectedTeam] = useState("")
  const [selectedLeague, setSelectedLeague] = useState("")
  const [isImporting, setIsImporting] = useState(false)

  const handleImport = async () => {
    if (!session?.user?.id || !selectedTeam || !selectedLeague) return

    setIsImporting(true)
    try {
      const events = await importSeasonSchedule(session.user.id, selectedTeam, selectedLeague)

      toast({
        title: "Season schedule imported",
        description: `Successfully imported ${events.length} games from the season schedule.`,
      })
    } catch (error) {
      console.error("Error importing season schedule:", error)
      toast({
        title: "Error",
        description: "Failed to import season schedule. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsImporting(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Import Season Schedule</CardTitle>
        <CardDescription>Import your team's season schedule to your calendar</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="team">Team</Label>
            <Select value={selectedTeam} onValueChange={setSelectedTeam}>
              <SelectTrigger id="team">
                <SelectValue placeholder="Select a team" />
              </SelectTrigger>
              <SelectContent>
                {teams.map((team) => (
                  <SelectItem key={team.id} value={team.id}>
                    {team.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="league">League</Label>
            <Select value={selectedLeague} onValueChange={setSelectedLeague}>
              <SelectTrigger id="league">
                <SelectValue placeholder="Select a league" />
              </SelectTrigger>
              <SelectContent>
                {leagues.map((league) => (
                  <SelectItem key={league.id} value={league.id}>
                    {league.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleImport} disabled={!selectedTeam || !selectedLeague || isImporting}>
            {isImporting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Importing...
              </>
            ) : (
              "Import Schedule"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
