"use client"

import { useState, useEffect } from "react"
import { Calendar, dateFnsLocalizer } from "react-big-calendar"
import { format, parse, startOfWeek, getDay } from "date-fns"
import { enUS } from "date-fns/locale"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { type CalendarEvent, getUserCalendarEvents } from "@/services/calendarService"
import { useSession } from "next-auth/react"
import { Loader2 } from "lucide-react"

// Setup the localizer for react-big-calendar
const locales = {
  "en-US": enUS,
}

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
})

export function CalendarView() {
  const { data: session } = useSession()
  const [events, setEvents] = useState<CalendarEvent[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [view, setView] = useState("month")
  const [date, setDate] = useState(new Date())

  useEffect(() => {
    async function loadEvents() {
      if (session?.user?.id) {
        setIsLoading(true)
        try {
          const userEvents = await getUserCalendarEvents(session.user.id)
          setEvents(userEvents)
        } catch (error) {
          console.error("Error loading calendar events:", error)
        } finally {
          setIsLoading(false)
        }
      }
    }

    loadEvents()
  }, [session?.user?.id])

  // Convert our events to the format expected by react-big-calendar
  const calendarEvents = events.map((event) => ({
    id: event.id,
    title: event.title,
    start: new Date(event.start),
    end: new Date(event.end),
    allDay: event.allDay || false,
    resource: {
      location: event.location,
      description: event.description,
      source: event.source,
    },
  }))

  // Custom event component to show different colors based on source
  const EventComponent = ({ event }) => {
    let bgColor = "bg-blue-500"

    if (event.resource?.source === "google") {
      bgColor = "bg-green-500"
    } else if (event.resource?.source === "apple") {
      bgColor = "bg-gray-500"
    } else if (event.resource?.source === "outlook") {
      bgColor = "bg-purple-500"
    }

    return <div className={`${bgColor} text-white p-1 rounded text-sm overflow-hidden`}>{event.title}</div>
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>My Calendar</CardTitle>
        <CardDescription>Manage your availability and view upcoming games</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[600px]">
          <Calendar
            localizer={localizer}
            events={calendarEvents}
            startAccessor="start"
            endAccessor="end"
            style={{ height: "100%" }}
            views={["month", "week", "day"]}
            view={view as any}
            onView={(newView) => setView(newView)}
            date={date}
            onNavigate={setDate}
            components={{
              event: EventComponent,
            }}
          />
        </div>
      </CardContent>
    </Card>
  )
}
