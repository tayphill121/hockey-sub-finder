"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"
import {
  connectGoogleCalendar,
  connectAppleCalendar,
  connectOutlookCalendar,
  importGoogleCalendarEvents,
} from "@/services/calendarService"
import { useSession } from "next-auth/react"
import { Loader2 } from "lucide-react"

export function CalendarIntegrations() {
  const { data: session } = useSession()
  const [isConnectingGoogle, setIsConnectingGoogle] = useState(false)
  const [isConnectingApple, setIsConnectingApple] = useState(false)
  const [isConnectingOutlook, setIsConnectingOutlook] = useState(false)
  const [isImportingGoogle, setIsImportingGoogle] = useState(false)

  const handleConnectGoogle = async () => {
    if (!session?.user?.id) return

    setIsConnectingGoogle(true)
    try {
      // In a real implementation, you would redirect to Google OAuth
      // For demo purposes, we'll simulate a successful connection
      const authCode = "mock-auth-code"
      const success = await connectGoogleCalendar(session.user.id, authCode)

      if (success) {
        toast({
          title: "Google Calendar connected",
          description: "Your Google Calendar has been successfully connected.",
        })
      }
    } catch (error) {
      console.error("Error connecting Google Calendar:", error)
      toast({
        title: "Error",
        description: "Failed to connect Google Calendar. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsConnectingGoogle(false)
    }
  }

  const handleConnectApple = async () => {
    if (!session?.user?.id) return

    setIsConnectingApple(true)
    try {
      // In a real implementation, you would handle Apple Calendar integration
      // For demo purposes, we'll simulate a successful connection
      const success = await connectAppleCalendar(session.user.id, {})

      if (success) {
        toast({
          title: "Apple Calendar connected",
          description: "Your Apple Calendar has been successfully connected.",
        })
      }
    } catch (error) {
      console.error("Error connecting Apple Calendar:", error)
      toast({
        title: "Error",
        description: "Failed to connect Apple Calendar. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsConnectingApple(false)
    }
  }

  const handleConnectOutlook = async () => {
    if (!session?.user?.id) return

    setIsConnectingOutlook(true)
    try {
      // In a real implementation, you would handle Outlook Calendar integration
      // For demo purposes, we'll simulate a successful connection
      const success = await connectOutlookCalendar(session.user.id, {})

      if (success) {
        toast({
          title: "Outlook Calendar connected",
          description: "Your Outlook Calendar has been successfully connected.",
        })
      }
    } catch (error) {
      console.error("Error connecting Outlook Calendar:", error)
      toast({
        title: "Error",
        description: "Failed to connect Outlook Calendar. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsConnectingOutlook(false)
    }
  }

  const handleImportGoogleEvents = async () => {
    if (!session?.user?.id) return

    setIsImportingGoogle(true)
    try {
      const events = await importGoogleCalendarEvents(session.user.id)

      toast({
        title: "Events imported",
        description: `Successfully imported ${events.length} events from Google Calendar.`,
      })
    } catch (error) {
      console.error("Error importing Google Calendar events:", error)
      toast({
        title: "Error",
        description: "Failed to import events from Google Calendar. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsImportingGoogle(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Calendar Integrations</CardTitle>
        <CardDescription>Connect your external calendars to sync your availability</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="space-y-2">
            <h3 className="text-lg font-medium">Google Calendar</h3>
            <p className="text-sm text-muted-foreground">
              Connect your Google Calendar to automatically sync your availability.
            </p>
            <div className="flex space-x-2">
              <Button onClick={handleConnectGoogle} disabled={isConnectingGoogle}>
                {isConnectingGoogle ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  "Connect Google Calendar"
                )}
              </Button>
              <Button variant="outline" onClick={handleImportGoogleEvents} disabled={isImportingGoogle}>
                {isImportingGoogle ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Importing...
                  </>
                ) : (
                  "Import Events"
                )}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-lg font-medium">Apple Calendar</h3>
            <p className="text-sm text-muted-foreground">
              Connect your Apple Calendar to automatically sync your availability.
            </p>
            <Button onClick={handleConnectApple} disabled={isConnectingApple}>
              {isConnectingApple ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Connecting...
                </>
              ) : (
                "Connect Apple Calendar"
              )}
            </Button>
          </div>

          <div className="space-y-2">
            <h3 className="text-lg font-medium">Outlook Calendar</h3>
            <p className="text-sm text-muted-foreground">
              Connect your Outlook Calendar to automatically sync your availability.
            </p>
            <Button onClick={handleConnectOutlook} disabled={isConnectingOutlook}>
              {isConnectingOutlook ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Connecting...
                </>
              ) : (
                "Connect Outlook Calendar"
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
