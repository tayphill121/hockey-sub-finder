"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, Clock, Mail, Phone } from "lucide-react"

interface SubRequestResponse {
  playerId: string
  playerName: string
  playerAvatar?: string
  playerPosition: string
  playerContact: {
    email: string
    phone: string
  }
  response: "accept" | "decline"
  timestamp: string
}

interface SubRequestResponsesProps {
  requestId: string
  responses: SubRequestResponse[]
  positionsNeeded: string[]
}

export function SubRequestResponses({ requestId, responses, positionsNeeded }: SubRequestResponsesProps) {
  const [showContact, setShowContact] = useState<Record<string, boolean>>({})

  const acceptedResponses = responses.filter((r) => r.response === "accept")
  const declinedResponses = responses.filter((r) => r.response === "decline")

  const toggleContact = (playerId: string) => {
    setShowContact((prev) => ({
      ...prev,
      [playerId]: !prev[playerId],
    }))
  }

  // Group accepted responses by position
  const acceptedByPosition = acceptedResponses.reduce(
    (acc, response) => {
      if (!acc[response.playerPosition]) {
        acc[response.playerPosition] = []
      }
      acc[response.playerPosition].push(response)
      return acc
    },
    {} as Record<string, SubRequestResponse[]>,
  )

  // Check if all positions are filled
  const allPositionsFilled = positionsNeeded.every((position) => {
    const acceptedCount = acceptedByPosition[position]?.length || 0
    const neededCount = positionsNeeded.filter((p) => p === position).length
    return acceptedCount >= neededCount
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sub Request Responses</CardTitle>
        <CardDescription>
          {allPositionsFilled
            ? "All positions have been filled"
            : `${acceptedResponses.length} of ${positionsNeeded.length} positions filled`}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-sm font-medium flex items-center">
            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
            Accepted ({acceptedResponses.length})
          </h3>
          {acceptedResponses.length > 0 ? (
            <div className="space-y-2">
              {acceptedResponses.map((response) => (
                <div
                  key={response.playerId}
                  className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-md"
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={response.playerAvatar || "/placeholder.svg"} alt={response.playerName} />
                      <AvatarFallback>{response.playerName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{response.playerName}</div>
                      <div className="text-xs text-muted-foreground flex items-center">
                        <Badge variant="outline" className="mr-2">
                          {response.playerPosition}
                        </Badge>
                        <Clock className="h-3 w-3 mr-1" />
                        {new Date(response.timestamp).toLocaleString()}
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleContact(response.playerId)}
                    className="text-xs"
                  >
                    {showContact[response.playerId] ? "Hide Contact" : "Show Contact"}
                  </Button>
                </div>
              ))}
              {Object.entries(showContact).map(
                ([playerId, show]) =>
                  show && (
                    <div key={`contact-${playerId}`} className="p-3 bg-muted rounded-md text-sm space-y-2 mt-1 ml-10">
                      <div className="flex items-center">
                        <Mail className="h-4 w-4 mr-2" />
                        <a href={`mailto:${responses.find((r) => r.playerId === playerId)?.playerContact.email}`}>
                          {responses.find((r) => r.playerId === playerId)?.playerContact.email}
                        </a>
                      </div>
                      <div className="flex items-center">
                        <Phone className="h-4 w-4 mr-2" />
                        <a href={`tel:${responses.find((r) => r.playerId === playerId)?.playerContact.phone}`}>
                          {responses.find((r) => r.playerId === playerId)?.playerContact.phone}
                        </a>
                      </div>
                    </div>
                  ),
              )}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No players have accepted yet.</p>
          )}
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-medium flex items-center">
            <XCircle className="h-4 w-4 text-red-500 mr-2" />
            Declined ({declinedResponses.length})
          </h3>
          {declinedResponses.length > 0 ? (
            <div className="space-y-2">
              {declinedResponses.map((response) => (
                <div
                  key={response.playerId}
                  className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/10 rounded-md"
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={response.playerAvatar || "/placeholder.svg"} alt={response.playerName} />
                      <AvatarFallback>{response.playerName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{response.playerName}</div>
                      <div className="text-xs text-muted-foreground flex items-center">
                        <Badge variant="outline" className="mr-2">
                          {response.playerPosition}
                        </Badge>
                        <Clock className="h-3 w-3 mr-1" />
                        {new Date(response.timestamp).toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No players have declined.</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
