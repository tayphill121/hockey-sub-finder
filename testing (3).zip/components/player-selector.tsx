"use client"

import { useState } from "react"
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Search, GripVertical, X } from "lucide-react"
import { Input } from "@/components/ui/input"

interface Player {
  id: string
  name: string
  position: string
  rating?: number
  avatarUrl?: string
}

interface PlayerSelectorProps {
  availablePlayers: Player[]
  selectedPlayers: string[]
  onChange: (selectedPlayers: string[]) => void
  maxSelections: number
}

export function PlayerSelector({ availablePlayers, selectedPlayers, onChange, maxSelections }: PlayerSelectorProps) {
  const [searchTerm, setSearchTerm] = useState("")

  // Filter available players based on search term and already selected players
  const filteredPlayers = availablePlayers.filter(
    (player) =>
      !selectedPlayers.includes(player.id) &&
      (player.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        player.position.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  // Get the selected player objects in order
  const orderedSelectedPlayers = selectedPlayers
    .map((id) => availablePlayers.find((player) => player.id === id))
    .filter((player): player is Player => player !== undefined)

  const handleAddPlayer = (playerId: string) => {
    if (selectedPlayers.length < maxSelections) {
      onChange([...selectedPlayers, playerId])
    }
  }

  const handleRemovePlayer = (playerId: string) => {
    onChange(selectedPlayers.filter((id) => id !== playerId))
  }

  const handleDragEnd = (result: any) => {
    if (!result.destination) return

    const items = Array.from(selectedPlayers)
    const [reorderedItem] = items.splice(result.source.index, 1)
    items.splice(result.destination.index, 0, reorderedItem)

    onChange(items)
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="flex items-center border rounded-md px-3 py-2">
          <Search className="h-4 w-4 mr-2 opacity-50" />
          <Input
            placeholder="Search players by name or position..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="border-0 p-0 focus-visible:ring-0 focus-visible:ring-offset-0"
          />
        </div>
        <div className="text-sm text-muted-foreground">
          {selectedPlayers.length}/{maxSelections} players selected
        </div>
      </div>

      <div className="border rounded-md p-4 space-y-4">
        <h4 className="text-sm font-medium">Selected Players (in order of preference)</h4>
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="selected-players">
            {(provided) => (
              <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
                {orderedSelectedPlayers.length === 0 ? (
                  <div className="text-sm text-muted-foreground py-2">
                    No players selected. Add players from the list below.
                  </div>
                ) : (
                  orderedSelectedPlayers.map((player, index) => (
                    <Draggable key={player.id} draggableId={player.id} index={index}>
                      {(provided) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className="flex items-center justify-between bg-muted/50 rounded-md p-2"
                        >
                          <div className="flex items-center gap-2">
                            <div {...provided.dragHandleProps} className="cursor-grab">
                              <GripVertical className="h-4 w-4 opacity-50" />
                            </div>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={player.avatarUrl || "/placeholder.svg"} alt={player.name} />
                                <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{player.name}</div>
                                <div className="text-xs text-muted-foreground">{player.position}</div>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">Priority {index + 1}</Badge>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleRemovePlayer(player.id)}
                              className="h-6 w-6"
                            >
                              <X className="h-4 w-4" />
                              <span className="sr-only">Remove</span>
                            </Button>
                          </div>
                        </div>
                      )}
                    </Draggable>
                  ))
                )}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </div>

      <div className="border rounded-md p-4">
        <h4 className="text-sm font-medium mb-2">Available Players</h4>
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {filteredPlayers.length === 0 ? (
            <div className="text-sm text-muted-foreground py-2">No matching players found.</div>
          ) : (
            filteredPlayers.map((player) => (
              <div key={player.id} className="flex items-center justify-between p-2 hover:bg-muted/50 rounded-md">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={player.avatarUrl || "/placeholder.svg"} alt={player.name} />
                    <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{player.name}</div>
                    <div className="text-xs text-muted-foreground">{player.position}</div>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleAddPlayer(player.id)}
                  disabled={selectedPlayers.length >= maxSelections}
                >
                  Add
                </Button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
