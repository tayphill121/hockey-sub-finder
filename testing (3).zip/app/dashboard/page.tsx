"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, MapPin, Plus, User, Users } from "lucide-react"
import { getSubRequests } from "./request-sub/actions"
import { useSession } from "next-auth/react"
import { toast } from "@/components/ui/use-toast"

export default function DashboardPage() {
  const router = useRouter()
  const { data: session, status } = useSession()
  const [activeTab, setActiveTab] = useState("player")
  const [subRequests, setSubRequests] = useState([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Set default tab based on user role
    if (session?.user?.role === "team") {
      setActiveTab("team")
    } else {
      setActiveTab("player")
    }

    // Fetch sub requests
    async function fetchSubRequests() {
      try {
        const requests = await getSubRequests()
        setSubRequests(requests)
      } catch (error) {
        console.error("Error fetching sub requests:", error)
        toast({
          title: "Error",
          description: "Failed to load sub requests",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchSubRequests()
  }, [session])

  // Redirect to login if not authenticated
  if (status === "unauthenticated") {
    router.push("/login")
    return null
  }

  // Show loading state
  if (status === "loading" || isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  // Format date for display
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  // Format time for display
  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    return `${hour > 12 ? hour - 12 : hour}:${minutes} ${hour >= 12 ? "PM" : "AM"}`
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Link href="/" className="font-bold text-xl">
              HockeySubFinder
            </Link>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/dashboard" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/dashboard/calendar" className="text-sm font-medium">
              Calendar
            </Link>
            <Link href="/profile" className="text-sm font-medium">
              Profile
            </Link>
            <Link href="/messages" className="text-sm font-medium">
              Messages
            </Link>
          </nav>
          <div className="flex items-center gap-2">
            <div className="text-sm mr-2">{session?.user?.name || "User"}</div>
            <Button variant="ghost" size="icon">
              <User className="h-5 w-5" />
              <span className="sr-only">User</span>
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-8">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-gray-500">Manage your hockey sub requests and availability</p>
          </div>

          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="player">Player View</TabsTrigger>
              <TabsTrigger value="team">Team Manager View</TabsTrigger>
            </TabsList>

            <TabsContent value="player" className="space-y-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Available Sub Opportunities</CardTitle>
                  <CardDescription>Games looking for substitute players</CardDescription>
                </CardHeader>
                <CardContent>
                  {subRequests.length > 0 ? (
                    <div className="grid gap-4">
                      {subRequests.map((game) => (
                        <Card key={game.id}>
                          <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row justify-between gap-4">
                              <div className="space-y-2">
                                <h3 className="font-bold">{game.teamName}</h3>
                                <div className="flex items-center gap-2 text-sm text-gray-500">
                                  <Calendar className="h-4 w-4" />
                                  <span>{formatDate(game.date)}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-gray-500">
                                  <Clock className="h-4 w-4" />
                                  <span>{formatTime(game.time)}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-gray-500">
                                  <MapPin className="h-4 w-4" />
                                  <span>{game.location}</span>
                                </div>
                              </div>
                              <div className="space-y-2">
                                <h4 className="font-medium">Positions Needed:</h4>
                                <div className="flex flex-wrap gap-2">
                                  {game.positionsNeeded.map((position) => (
                                    <span
                                      key={position}
                                      className="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs"
                                    >
                                      {position.charAt(0).toUpperCase() + position.slice(1)}
                                    </span>
                                  ))}
                                </div>
                                <Button className="w-full mt-2">Apply to Sub</Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-gray-500">No games currently looking for subs</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>My Availability</CardTitle>
                  <CardDescription>Set when you're available to play</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => (
                        <Button key={day} variant="outline" className="justify-start">
                          {day}
                        </Button>
                      ))}
                    </div>
                    <Button className="w-full md:w-auto">Update Availability</Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>My Calendar</CardTitle>
                  <CardDescription>Manage your availability and sync with external calendars</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-sm">
                      Set your recurring availability, mark blackout dates, and sync with your external calendars to
                      make it easier to find substitute opportunities that match your schedule.
                    </p>
                    <Link href="/dashboard/calendar">
                      <Button>Manage Calendar</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="team" className="space-y-6 mt-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>My Sub Requests</CardTitle>
                    <CardDescription>Manage your team's substitute requests</CardDescription>
                  </div>
                  <Link href="/dashboard/request-sub">
                    <Button>
                      <Plus className="mr-2 h-4 w-4" /> New Request
                    </Button>
                  </Link>
                </CardHeader>
                <CardContent>
                  {subRequests.length > 0 ? (
                    <div className="grid gap-4">
                      {subRequests.map((request) => (
                        <Card key={request.id}>
                          <CardContent className="p-4">
                            <div className="flex flex-col md:flex-row justify-between gap-4">
                              <div className="space-y-2">
                                <h3 className="font-bold">{request.teamName}</h3>
                                <div className="flex items-center gap-2 text-sm text-gray-500">
                                  <Calendar className="h-4 w-4" />
                                  <span>{formatDate(request.date)}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-gray-500">
                                  <Clock className="h-4 w-4" />
                                  <span>{formatTime(request.time)}</span>
                                </div>
                                <div className="flex items-center gap-2 text-sm text-gray-500">
                                  <MapPin className="h-4 w-4" />
                                  <span>{request.location}</span>
                                </div>
                              </div>
                              <div className="space-y-2">
                                <h4 className="font-medium">Positions Needed:</h4>
                                <div className="flex flex-wrap gap-2">
                                  {request.positionsNeeded.map((position) => (
                                    <span
                                      key={position}
                                      className="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs"
                                    >
                                      {position.charAt(0).toUpperCase() + position.slice(1)}
                                    </span>
                                  ))}
                                </div>
                                <div className="flex gap-2 mt-2">
                                  <Button variant="outline" size="sm" className="flex-1">
                                    Edit
                                  </Button>
                                  <Button variant="outline" size="sm" className="flex-1">
                                    View Applicants
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-gray-500">You haven't created any sub requests yet</p>
                      <Link href="/dashboard/request-sub">
                        <Button className="mt-4">
                          <Plus className="mr-2 h-4 w-4" /> Create Sub Request
                        </Button>
                      </Link>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Add this new card for the Goalie Registry */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Goalie Registry</CardTitle>
                    <CardDescription>Find available goalies for your games</CardDescription>
                  </div>
                  <Link href="/dashboard/goalie-registry">
                    <Button variant="outline">View Goalies</Button>
                  </Link>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-500">
                    Access our exclusive registry of available goalies. Contact them directly to arrange substitutions.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>My Teams</CardTitle>
                  <CardDescription>Manage your hockey teams</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex flex-col md:flex-row justify-between gap-4">
                          <div className="space-y-2">
                            <h3 className="font-bold">Maple Leafs</h3>
                            <div className="flex items-center gap-2 text-sm text-gray-500">
                              <span>City League</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-gray-500">
                              <Users className="h-4 w-4" />
                              <span>15 players</span>
                            </div>
                          </div>
                          <div className="space-y-2 flex flex-col">
                            <Button className="w-full">Manage Team</Button>
                            <Link href="/dashboard/request-sub" className="w-full">
                              <Button variant="outline" className="w-full">
                                Request Subs
                              </Button>
                            </Link>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">© 2025 HockeySubFinder. All rights reserved.</p>
          <nav className="flex gap-4">
            <Link href="/terms" className="text-sm text-gray-500 hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-gray-500 hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-gray-500 hover:underline">
              Contact
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}
