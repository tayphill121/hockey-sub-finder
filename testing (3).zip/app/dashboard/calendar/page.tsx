"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarView } from "@/components/calendar/calendar-view"
import { RecurringAvailabilitySettings } from "@/components/calendar/recurring-availability"
import { BlackoutDatesManager } from "@/components/calendar/blackout-dates"
import { CalendarIntegrations } from "@/components/calendar/calendar-integrations"
import { SeasonImport } from "@/components/calendar/season-import"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"

export default function CalendarPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("calendar")

  // Redirect to login if not authenticated
  if (status === "unauthenticated") {
    router.push("/login")
    return null
  }

  // Show loading state
  if (status === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <a href="/dashboard" className="font-bold text-xl">
              HockeySubFinder
            </a>
          </div>
          <nav className="hidden md:flex gap-6">
            <a href="/dashboard" className="text-sm font-medium">
              Dashboard
            </a>
            <a href="/dashboard/calendar" className="text-sm font-medium text-primary">
              Calendar
            </a>
            <a href="/profile" className="text-sm font-medium">
              Profile
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <div className="text-sm mr-2">{session?.user?.name || "User"}</div>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-8">
          <div>
            <h1 className="text-3xl font-bold">Calendar Management</h1>
            <p className="text-gray-500">Manage your availability and sync your calendars</p>
          </div>

          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-5">
              <TabsTrigger value="calendar">Calendar</TabsTrigger>
              <TabsTrigger value="recurring">Recurring</TabsTrigger>
              <TabsTrigger value="blackout">Blackout Dates</TabsTrigger>
              <TabsTrigger value="integrations">Integrations</TabsTrigger>
              <TabsTrigger value="season">Season Import</TabsTrigger>
            </TabsList>

            <TabsContent value="calendar" className="space-y-6 mt-6">
              <CalendarView />
            </TabsContent>

            <TabsContent value="recurring" className="space-y-6 mt-6">
              <RecurringAvailabilitySettings />
            </TabsContent>

            <TabsContent value="blackout" className="space-y-6 mt-6">
              <BlackoutDatesManager />
            </TabsContent>

            <TabsContent value="integrations" className="space-y-6 mt-6">
              <CalendarIntegrations />
            </TabsContent>

            <TabsContent value="season" className="space-y-6 mt-6">
              <SeasonImport />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <footer className="border-t py-6">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">© 2025 HockeySubFinder. All rights reserved.</p>
          <nav className="flex gap-4">
            <a href="/terms" className="text-sm text-gray-500 hover:underline">
              Terms
            </a>
            <a href="/privacy" className="text-sm text-gray-500 hover:underline">
              Privacy
            </a>
            <a href="/contact" className="text-sm text-gray-500 hover:underline">
              Contact
            </a>
          </nav>
        </div>
      </footer>
    </div>
  )
}
