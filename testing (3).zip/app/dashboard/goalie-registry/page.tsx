"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useSession } from "next-auth/react"
import { toast } from "@/components/ui/use-toast"

// Mock data for demonstration
const goalies = [
  {
    id: "1",
    name: "Mike Smith",
    experience: "10+ years",
    availability: ["Monday", "Wednesday", "Friday"],
    location: "Downtown",
    rating: 4.8,
    contact: "mike@example.com",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    experience: "5 years",
    availability: ["Tuesday", "Thursday", "Saturday"],
    location: "Westside",
    rating: 4.5,
    contact: "sarah@example.com",
  },
  {
    id: "3",
    name: "David Lee",
    experience: "8 years",
    availability: ["Monday", "Thursday", "Sunday"],
    location: "Eastside",
    rating: 4.9,
    contact: "david@example.com",
  },
  {
    id: "4",
    name: "Emma Wilson",
    experience: "3 years",
    availability: ["Wednesday", "Friday", "Saturday"],
    location: "Northside",
    rating: 4.2,
    contact: "emma@example.com",
  },
]

export default function GoalieRegistryPage() {
  const router = useRouter()
  const { data: session, status } = useSession()
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredGoalies, setFilteredGoalies] = useState(goalies)

  useEffect(() => {
    // Only teams should access this page
    if (status === "authenticated") {
      if (session.user.role !== "team") {
        toast({
          title: "Access Denied",
          description: "Only team managers can access the goalie registry.",
          variant: "destructive",
        })
        router.push("/dashboard")
      }

      // Check if team has paid
      if (!session.user.isPaid) {
        toast({
          title: "Subscription Required",
          description: "You need to purchase a team subscription to access the goalie registry.",
          variant: "destructive",
        })
        router.push("/payment")
      }

      setIsLoading(false)
    } else if (status === "unauthenticated") {
      router.push("/login")
    }
  }, [session, status, router])

  useEffect(() => {
    if (searchTerm) {
      const filtered = goalies.filter(
        (goalie) =>
          goalie.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          goalie.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
          goalie.availability.some((day) => day.toLowerCase().includes(searchTerm.toLowerCase())),
      )
      setFilteredGoalies(filtered)
    } else {
      setFilteredGoalies(goalies)
    }
  }, [searchTerm])

  const handleContactGoalie = (goalie) => {
    toast({
      title: "Contact Information",
      description: `You can reach ${goalie.name} at ${goalie.contact}`,
    })
  }

  if (isLoading) {
    return (
      <div className="container py-10 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading goalie registry...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container py-10">
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold">Goalie Registry</h1>
          <p className="text-gray-500">Find available goalies for your games</p>
        </div>

        <div className="flex items-center gap-4">
          <Input
            placeholder="Search by name, location, or availability..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-md"
          />
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {filteredGoalies.map((goalie) => (
            <Card key={goalie.id}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{goalie.name}</CardTitle>
                    <CardDescription>
                      {goalie.location} • {goalie.experience}
                    </CardDescription>
                  </div>
                  <div className="bg-primary/10 text-primary px-2 py-1 rounded-md text-sm font-medium">
                    {goalie.rating} ★
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium mb-1">Availability</p>
                    <div className="flex flex-wrap gap-2">
                      {goalie.availability.map((day) => (
                        <Badge key={day} variant="outline">
                          {day}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Button onClick={() => handleContactGoalie(goalie)} className="w-full">
                    Contact Goalie
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredGoalies.length === 0 && (
            <div className="col-span-2 text-center py-10">
              <p className="text-gray-500">No goalies found matching your search criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
