"use server"

import { sendNotifications } from "../../../services/notificationService"

// In a real app, this would connect to your database
// For demo purposes, we'll use an in-memory store
const subRequests = [
  {
    id: "1",
    teamName: "Maple Leafs",
    date: "2025-05-10",
    time: "19:00",
    location: "City Ice Arena",
    requestType: "open",
    positionsNeeded: ["forward", "defense"],
    selectedPlayers: [],
    description: "Regular season game, need 2 subs.",
    urgency: "normal",
    responseDeadline: 12,
    status: "open",
    responses: [],
    createdAt: "2025-04-23T12:00:00Z",
  },
  {
    id: "2",
    teamName: "Bruins",
    date: "2025-05-15",
    time: "20:30",
    location: "Community Rink",
    requestType: "open",
    positionsNeeded: ["goalie"],
    selectedPlayers: [],
    description: "Our regular goalie is out of town.",
    urgency: "urgent",
    responseDeadline: 6,
    status: "open",
    responses: [],
    createdAt: "2025-04-24T14:30:00Z",
  },
]

export async function createSubRequest(data: {
  teamName: string
  date: string
  time: string
  location: string
  requestType: "open" | "targeted"
  positionsNeeded: string[]
  selectedPlayers: string[]
  description: string
  urgency: "normal" | "urgent"
  responseDeadline: number
}) {
  try {
    // Validate required fields
    if (!data.teamName || !data.date || !data.time || !data.location || !data.positionsNeeded.length) {
      return { error: "Missing required fields" }
    }

    // Validate that if requestType is targeted, selectedPlayers must not be empty
    if (data.requestType === "targeted" && data.selectedPlayers.length === 0) {
      return { error: "Please select at least one player for targeted requests" }
    }

    // Create new request
    const newRequest = {
      id: (subRequests.length + 1).toString(),
      ...data,
      status: "open",
      responses: [],
      createdAt: new Date().toISOString(),
    }

    // Add to our "database"
    subRequests.push(newRequest)

    // Send notifications to players
    await sendNotifications(newRequest)

    return { success: true, request: newRequest }
  } catch (error) {
    console.error("Error creating sub request:", error)
    return { error: "Failed to create sub request" }
  }
}

export async function getSubRequests() {
  // In a real app, you would filter by user role, etc.
  return subRequests
}

export async function respondToSubRequest(requestId: string, playerId: string, response: "accept" | "decline") {
  try {
    const request = subRequests.find((req) => req.id === requestId)
    if (!request) {
      return { error: "Request not found" }
    }

    // Add response to the request
    request.responses.push({
      playerId,
      response,
      timestamp: new Date().toISOString(),
    })

    // If this is a targeted request and the player accepted, update status
    if (request.requestType === "targeted" && response === "accept") {
      // Check if all positions are filled
      const acceptedCount = request.responses.filter((r) => r.response === "accept").length
      if (acceptedCount >= request.positionsNeeded.length) {
        request.status = "filled"
      }
    }

    // If this is an open request and the player accepted, update status
    if (request.requestType === "open" && response === "accept") {
      // Check if all positions are filled
      const acceptedCount = request.responses.filter((r) => r.response === "accept").length
      if (acceptedCount >= request.positionsNeeded.length) {
        request.status = "filled"
      }
    }

    return { success: true }
  } catch (error) {
    console.error("Error responding to sub request:", error)
    return { error: "Failed to respond to sub request" }
  }
}
