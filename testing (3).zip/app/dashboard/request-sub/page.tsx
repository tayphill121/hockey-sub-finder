"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { toast } from "@/components/ui/use-toast"
import { createSubRequest } from "./actions"
import { getAvailablePlayers } from "../../../services/playerService"
import { PlayerSelector } from "@/components/player-selector"

const formSchema = z.object({
  teamName: z.string().min(2, { message: "Team name is required" }),
  gameDate: z.string().min(1, { message: "Game date is required" }),
  gameTime: z.string().min(1, { message: "Game time is required" }),
  location: z.string().min(2, { message: "Location is required" }),
  requestType: z.enum(["open", "targeted"], { required_error: "Please select a request type" }),
  positionsNeeded: z.array(z.string()).min(1, { message: "Select at least one position" }),
  selectedPlayers: z.array(z.string()).optional(),
  description: z.string().optional(),
  urgency: z.enum(["normal", "urgent"], { required_error: "Please select urgency level" }).default("normal"),
  responseDeadline: z.number().int().min(1).max(48).default(12),
})

const positions = [
  { id: "forward", label: "Forward" },
  { id: "defense", label: "Defense" },
  { id: "goalie", label: "Goalie" },
]

export default function RequestSubPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [availablePlayers, setAvailablePlayers] = useState([])
  const [selectedTab, setSelectedTab] = useState("open")

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      teamName: "",
      gameDate: "",
      gameTime: "",
      location: "",
      requestType: "open",
      positionsNeeded: [],
      selectedPlayers: [],
      description: "",
      urgency: "normal",
      responseDeadline: 12,
    },
  })

  // Watch the positions needed to filter available players
  const positionsNeeded = form.watch("positionsNeeded")

  useEffect(() => {
    // Load available players when positions change
    const loadPlayers = async () => {
      if (positionsNeeded.length > 0) {
        const players = await getAvailablePlayers(positionsNeeded)
        setAvailablePlayers(players)
      }
    }

    loadPlayers()
  }, [positionsNeeded])

  // Update the request type when tab changes
  useEffect(() => {
    form.setValue("requestType", selectedTab as "open" | "targeted")
  }, [selectedTab, form])

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true)

    try {
      const result = await createSubRequest({
        teamName: values.teamName,
        date: values.gameDate,
        time: values.gameTime,
        location: values.location,
        requestType: values.requestType,
        positionsNeeded: values.positionsNeeded,
        selectedPlayers: values.selectedPlayers || [],
        description: values.description || "",
        urgency: values.urgency,
        responseDeadline: values.responseDeadline,
      })

      if (result.error) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Success!",
        description: "Your sub request has been created and notifications will be sent to eligible players.",
      })

      router.push("/dashboard")
      router.refresh()
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container py-10">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Request Substitute Players</CardTitle>
          <CardDescription>Fill out the details for your upcoming game</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="teamName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Team Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your team name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="gameDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Game Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="gameTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Game Time</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter the rink or arena name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="positionsNeeded"
                render={() => (
                  <FormItem>
                    <div className="mb-4">
                      <FormLabel>Positions Needed</FormLabel>
                      <FormDescription>Select all positions you need substitutes for</FormDescription>
                    </div>
                    {positions.map((position) => (
                      <FormField
                        key={position.id}
                        control={form.control}
                        name="positionsNeeded"
                        render={({ field }) => {
                          return (
                            <FormItem key={position.id} className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(position.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...field.value, position.id])
                                      : field.onChange(field.value?.filter((value) => value !== position.id))
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="font-normal">{position.label}</FormLabel>
                            </FormItem>
                          )
                        }}
                      />
                    ))}
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-4">
                <div className="flex flex-col space-y-1.5">
                  <h3 className="text-sm font-medium">Request Type</h3>
                  <p className="text-sm text-muted-foreground">Choose how you want to find substitute players</p>
                </div>
                <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
                  <TabsList className="grid grid-cols-2">
                    <TabsTrigger value="open">Open Request</TabsTrigger>
                    <TabsTrigger value="targeted">Select Specific Players</TabsTrigger>
                  </TabsList>
                  <TabsContent value="open" className="space-y-4 pt-4">
                    <div className="text-sm">
                      <p>
                        Your request will be sent to all eligible players. The first players to respond will be
                        automatically confirmed.
                      </p>
                    </div>
                  </TabsContent>
                  <TabsContent value="targeted" className="space-y-4 pt-4">
                    <div className="text-sm mb-4">
                      <p>
                        Select up to 5 specific players in order of preference. We'll contact them one by one until
                        positions are filled.
                      </p>
                    </div>
                    <FormField
                      control={form.control}
                      name="selectedPlayers"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <PlayerSelector
                              availablePlayers={availablePlayers}
                              selectedPlayers={field.value || []}
                              onChange={field.onChange}
                              maxSelections={5}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>
                </Tabs>
              </div>

              <FormField
                control={form.control}
                name="urgency"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Urgency Level</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="normal" />
                          </FormControl>
                          <FormLabel className="font-normal">Normal - Need subs within a few days</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="urgent" />
                          </FormControl>
                          <FormLabel className="font-normal">Urgent - Need subs ASAP (within 24 hours)</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="responseDeadline"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Response Deadline</FormLabel>
                    <FormDescription>
                      How long should players have to respond before we move to the next player?
                    </FormDescription>
                    <div className="flex items-center space-x-4">
                      <FormControl>
                        <Input
                          type="number"
                          min={1}
                          max={48}
                          {...field}
                          onChange={(e) => field.onChange(Number.parseInt(e.target.value))}
                          className="w-20"
                        />
                      </FormControl>
                      <span>hours</span>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Additional Details</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Add any additional information about the game or requirements"
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Creating Request..." : "Create Sub Request"}
              </Button>
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => router.back()}>
            Cancel
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
