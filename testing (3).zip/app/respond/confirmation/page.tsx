"use client"

import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle } from "lucide-react"

export default function ConfirmationPage() {
  const searchParams = useSearchParams()
  const action = searchParams.get("action")

  const isAccepted = action === "accept"

  return (
    <div className="container flex items-center justify-center min-h-screen">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex justify-center mb-4">
            {isAccepted ? (
              <CheckCircle className="h-16 w-16 text-green-500" />
            ) : (
              <XCircle className="h-16 w-16 text-red-500" />
            )}
          </div>
          <CardTitle className="text-center text-2xl">
            {isAccepted ? "You're confirmed!" : "Response recorded"}
          </CardTitle>
          <CardDescription className="text-center">
            {isAccepted
              ? "Thank you for accepting this sub request."
              : "Thank you for letting us know you're unavailable."}
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          {isAccepted ? (
            <p>
              The team has been notified that you'll be there. You'll receive an email with all the details for the
              game.
            </p>
          ) : (
            <p>We've recorded your response and will find another player for this game.</p>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button asChild>
            <a href="https://hockeysubfinder.com">Return to Hockey Sub Finder</a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
