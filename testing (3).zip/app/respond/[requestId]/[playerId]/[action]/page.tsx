"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, Loader2 } from "lucide-react"
import { respondToSubRequest } from "../../../../dashboard/request-sub/actions"

export default function RespondPage({ params }) {
  const router = useRouter()
  const { requestId, playerId, action } = params
  const [isLoading, setIsLoading] = useState(true)
  const [isProcessing, setIsProcessing] = useState(false)
  const [requestDetails, setRequestDetails] = useState(null)
  const [error, setError] = useState("")
  const [autoAction, setAutoAction] = useState<"accept" | "decline" | null>(null)

  useEffect(() => {
    // Fetch request details
    async function fetchRequestDetails() {
      try {
        // In a real app, you would fetch the request details from your API
        // For demo purposes, we'll use mock data
        const response = await fetch(`/api/sub-requests/${requestId}`)
        if (!response.ok) {
          throw new Error("Failed to fetch request details")
        }

        const data = await response.json()
        setRequestDetails(data)
      } catch (error) {
        setError("Failed to load request details. The link may be invalid or expired.")
      } finally {
        setIsLoading(false)
      }
    }

    fetchRequestDetails()
  }, [requestId])

  const handleResponse = async (response: "accept" | "decline") => {
    setIsProcessing(true)
    try {
      const result = await respondToSubRequest(requestId, playerId, response)

      if (result.error) {
        setError(result.error)
        return
      }

      // Redirect to confirmation page
      router.push(`/respond/confirmation?action=${response}`)
    } catch (error) {
      setError("Failed to process your response. Please try again.")
    } finally {
      setIsProcessing(false)
    }
  }

  useEffect(() => {
    if (action === "accept" || action === "decline") {
      setAutoAction(action)
    }
  }, [action])

  useEffect(() => {
    if (autoAction) {
      handleResponse(autoAction)
    }
  }, [autoAction])

  if (isLoading) {
    return (
      <div className="container flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <Loader2 className="h-8 w-8 animate-spin mx-auto" />
            <p className="mt-2">Loading request details...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error) {
    return (
      <div className="container flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-center">{error}</p>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button onClick={() => router.push("/")}>Return to Home</Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="container flex items-center justify-center min-h-screen">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Hockey Sub Request</CardTitle>
          <CardDescription>
            {requestDetails?.teamName} is looking for a {requestDetails?.positionsNeeded.join(", ")}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1">
            <p className="text-sm font-medium">Date & Time</p>
            <p>
              {new Date(requestDetails?.date).toLocaleDateString()} at{" "}
              {requestDetails?.time.replace(/(\d{2}):(\d{2})/, (_, h, m) => {
                const hour = Number.parseInt(h)
                return `${hour > 12 ? hour - 12 : hour}:${m} ${hour >= 12 ? "PM" : "AM"}`
              })}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-sm font-medium">Location</p>
            <p>{requestDetails?.location}</p>
          </div>
          {requestDetails?.description && (
            <div className="space-y-1">
              <p className="text-sm font-medium">Additional Details</p>
              <p>{requestDetails.description}</p>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          <div className="grid grid-cols-2 gap-4 w-full">
            <Button
              variant="outline"
              className="w-full"
              onClick={() => handleResponse("decline")}
              disabled={isProcessing}
            >
              <XCircle className="mr-2 h-4 w-4" />
              Decline
            </Button>
            <Button className="w-full" onClick={() => handleResponse("accept")} disabled={isProcessing}>
              <CheckCircle className="mr-2 h-4 w-4" />
              Accept
            </Button>
          </div>
          {isProcessing && (
            <div className="text-center w-full">
              <Loader2 className="h-4 w-4 animate-spin mx-auto" />
              <p className="text-sm text-muted-foreground mt-1">Processing your response...</p>
            </div>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
