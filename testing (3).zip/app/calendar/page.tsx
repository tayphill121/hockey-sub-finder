"use client"

import { useState } from "react"
import Link from "next/link"

export default function CalendarPage() {
  const [activeTab, setActiveTab] = useState("calendar")

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-white">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Link href="/" className="font-bold text-xl">
              HockeySubFinder
            </Link>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/calendar" className="text-sm font-medium text-blue-600">
              Calendar
            </Link>
            <Link href="/profile" className="text-sm font-medium">
              Profile
            </Link>
          </nav>
          <div className="flex items-center gap-2">
            <div className="text-sm mr-2">John Smith</div>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-8">
          <div>
            <h1 className="text-3xl font-bold">Calendar Management</h1>
            <p className="text-gray-500">Manage your availability and sync your calendars</p>
          </div>

          <div className="w-full">
            <div className="flex border-b">
              {["calendar", "recurring", "blackout", "integrations", "season"].map((tab) => (
                <button
                  key={tab}
                  className={`px-4 py-2 ${activeTab === tab ? "border-b-2 border-blue-600 text-blue-600" : ""}`}
                  onClick={() => setActiveTab(tab)}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </div>

            <div className="mt-6">
              {activeTab === "calendar" && (
                <div className="bg-white p-6 rounded-lg shadow">
                  <div className="mb-4">
                    <h2 className="text-xl font-semibold">My Calendar</h2>
                    <p className="text-gray-500">Manage your availability and view upcoming games</p>
                  </div>
                  <div className="h-[500px] border rounded">
                    <div className="grid grid-cols-7 h-full">
                      <div className="border-r border-b p-2 text-center font-medium">Sun</div>
                      <div className="border-r border-b p-2 text-center font-medium">Mon</div>
                      <div className="border-r border-b p-2 text-center font-medium">Tue</div>
                      <div className="border-r border-b p-2 text-center font-medium">Wed</div>
                      <div className="border-r border-b p-2 text-center font-medium">Thu</div>
                      <div className="border-r border-b p-2 text-center font-medium">Fri</div>
                      <div className="border-b p-2 text-center font-medium">Sat</div>

                      {Array.from({ length: 35 }).map((_, i) => (
                        <div key={i} className="border-r border-b p-1 h-16 relative">
                          <div className="text-xs text-gray-500">{(i % 31) + 1}</div>
                          {i === 8 && (
                            <div className="absolute top-5 left-0 right-0 bg-blue-500 text-white text-xs p-1 rounded">
                              Hockey Game - 7PM
                            </div>
                          )}
                          {i === 15 && (
                            <div className="absolute top-5 left-0 right-0 bg-green-500 text-white text-xs p-1 rounded">
                              Practice - 6PM
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "recurring" && (
                <div className="bg-white p-6 rounded-lg shadow">
                  <div className="mb-4">
                    <h2 className="text-xl font-semibold">Recurring Availability</h2>
                    <p className="text-gray-500">Set your regular weekly availability for hockey games</p>
                  </div>
                  <div className="space-y-6">
                    {["Monday", "Wednesday", "Friday"].map((day) => (
                      <div key={day} className="flex items-center justify-between border-b pb-4">
                        <div className="flex items-center">
                          <div className="w-12 h-6 bg-blue-600 rounded-full relative">
                            <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                          </div>
                          <span className="ml-3">{day}</span>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div>
                            <span className="text-sm text-gray-500">From</span>
                            <div className="border rounded px-3 py-1">6:00 PM</div>
                          </div>
                          <div>
                            <span className="text-sm text-gray-500">To</span>
                            <div className="border rounded px-3 py-1">10:00 PM</div>
                          </div>
                        </div>
                      </div>
                    ))}
                    <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                      Save Availability
                    </button>
                  </div>
                </div>
              )}

              {activeTab === "blackout" && (
                <div className="bg-white p-6 rounded-lg shadow">
                  <div className="mb-4">
                    <h2 className="text-xl font-semibold">Blackout Dates</h2>
                    <p className="text-gray-500">Mark dates when you're unavailable to play</p>
                  </div>
                  <div className="space-y-6">
                    <div className="flex flex-wrap gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                        <div className="border rounded px-3 py-2">Pick a date</div>
                      </div>
                      <div className="flex-grow">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Reason (optional)</label>
                        <input type="text" placeholder="e.g., Family vacation" className="border rounded p-2 w-full" />
                      </div>
                      <div className="flex items-end">
                        <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Add Date</button>
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Your Blackout Dates</h3>
                      <div className="border rounded-md divide-y">
                        <div className="flex items-center justify-between p-3">
                          <div>
                            <p className="font-medium">May 20, 2025</p>
                            <p className="text-sm text-gray-500">Family vacation</p>
                          </div>
                          <button className="text-gray-400 hover:text-gray-600">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="16"
                              height="16"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M3 6h18"></path>
                              <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                            </svg>
                          </button>
                        </div>
                        <div className="flex items-center justify-between p-3">
                          <div>
                            <p className="font-medium">May 21, 2025</p>
                            <p className="text-sm text-gray-500">Family vacation</p>
                          </div>
                          <button className="text-gray-400 hover:text-gray-600">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="16"
                              height="16"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            >
                              <path d="M3 6h18"></path>
                              <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                              <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                            </svg>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <footer className="border-t py-6">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">© 2025 HockeySubFinder. All rights reserved.</p>
          <nav className="flex gap-4">
            <span className="text-sm text-gray-500 hover:underline">Terms</span>
            <span className="text-sm text-gray-500 hover:underline">Privacy</span>
            <span className="text-sm text-gray-500 hover:underline">Contact</span>
          </nav>
        </div>
      </footer>
    </div>
  )
}
