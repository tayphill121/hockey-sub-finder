"use server"
import { registerUser as authRegisterUser } from "../api/auth/[...nextauth]/route"

export async function registerUser(userData: {
  name: string
  email: string
  password: string
  role: string
  playerType?: string
}) {
  try {
    const result = await authRegisterUser(userData)
    return { success: true, user: result }
  } catch (error) {
    return { error: error.message || "Failed to register user" }
  }
}
