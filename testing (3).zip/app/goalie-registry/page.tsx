"use client"

import { useState } from "react"
import Link from "next/link"

// Mock data for goalies
const goalies = [
  {
    id: "1",
    name: "Mike Smith",
    experience: "10+ years",
    availability: ["Monday", "Wednesday", "Friday"],
    location: "Downtown",
    rating: 4.8,
    contact: "mike@example.com",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    experience: "5 years",
    availability: ["Tuesday", "Thursday", "Saturday"],
    location: "Westside",
    rating: 4.5,
    contact: "sarah@example.com",
  },
  {
    id: "3",
    name: "David Lee",
    experience: "8 years",
    availability: ["Monday", "Thursday", "Sunday"],
    location: "Eastside",
    rating: 4.9,
    contact: "david@example.com",
  },
  {
    id: "4",
    name: "Emma Wilson",
    experience: "3 years",
    availability: ["Wednesday", "Friday", "Saturday"],
    location: "Northside",
    rating: 4.2,
    contact: "emma@example.com",
  },
]

export default function GoalieRegistryPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [contactInfo, setContactInfo] = useState<string | null>(null)

  // Filter goalies based on search term
  const filteredGoalies = goalies.filter(
    (goalie) =>
      goalie.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      goalie.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      goalie.availability.some((day) => day.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const handleContactGoalie = (goalie) => {
    setContactInfo(`You can reach ${goalie.name} at ${goalie.contact}`)
    setTimeout(() => setContactInfo(null), 5000)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-white">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Link href="/" className="font-bold text-xl">
              HockeySubFinder
            </Link>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/calendar" className="text-sm font-medium">
              Calendar
            </Link>
            <Link href="/profile" className="text-sm font-medium">
              Profile
            </Link>
          </nav>
          <div className="flex items-center gap-2">
            <div className="text-sm mr-2">Team Manager</div>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-8">
          <div>
            <h1 className="text-3xl font-bold">Goalie Registry</h1>
            <p className="text-gray-500">Find available goalies for your games</p>
          </div>

          <div className="flex items-center gap-4">
            <input
              type="text"
              placeholder="Search by name, location, or availability..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="border rounded-md px-4 py-2 flex-grow"
            />
          </div>

          {contactInfo && <div className="bg-green-100 text-green-800 p-4 rounded-md">{contactInfo}</div>}

          <div className="grid gap-6 md:grid-cols-2">
            {filteredGoalies.map((goalie) => (
              <div key={goalie.id} className="bg-white rounded-lg shadow overflow-hidden">
                <div className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="text-xl font-bold">{goalie.name}</h2>
                      <p className="text-gray-500">
                        {goalie.location} • {goalie.experience}
                      </p>
                    </div>
                    <div className="bg-blue-100 text-blue-600 px-2 py-1 rounded-md text-sm font-medium">
                      {goalie.rating} ★
                    </div>
                  </div>
                  <div className="mt-4 space-y-4">
                    <div>
                      <p className="text-sm font-medium mb-1">Availability</p>
                      <div className="flex flex-wrap gap-2">
                        {goalie.availability.map((day) => (
                          <span key={day} className="border rounded-full px-3 py-1 text-sm">
                            {day}
                          </span>
                        ))}
                      </div>
                    </div>
                    <button
                      onClick={() => handleContactGoalie(goalie)}
                      className="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                    >
                      Contact Goalie
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {filteredGoalies.length === 0 && (
              <div className="col-span-2 text-center py-10">
                <p className="text-gray-500">No goalies found matching your search criteria.</p>
              </div>
            )}
          </div>
        </div>
      </main>
      <footer className="border-t py-6">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">© 2025 HockeySubFinder. All rights reserved.</p>
          <nav className="flex gap-4">
            <span className="text-sm text-gray-500 hover:underline">Terms</span>
            <span className="text-sm text-gray-500 hover:underline">Privacy</span>
            <span className="text-sm text-gray-500 hover:underline">Contact</span>
          </nav>
        </div>
      </footer>
    </div>
  )
}
