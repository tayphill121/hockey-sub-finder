"use client"

import { useState } from "react"
import { Calendar, Clock, MapPin, Plus, User } from "lucide-react"

// Mock data
const subRequests = [
  {
    id: "1",
    teamName: "Maple Leafs",
    date: "2025-05-10",
    time: "19:00",
    location: "City Ice Arena",
    positionsNeeded: ["forward", "defense"],
    description: "Regular season game, need 2 subs.",
  },
  {
    id: "2",
    teamName: "Bruins",
    date: "2025-05-15",
    time: "20:30",
    location: "Community Rink",
    positionsNeeded: ["goalie"],
    description: "Our regular goalie is out of town.",
  },
]

export default function Home() {
  const [activeTab, setActiveTab] = useState("player")

  // Format date for display
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  // Format time for display
  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(":")
    const hour = Number.parseInt(hours)
    return `${hour > 12 ? hour - 12 : hour}:${minutes} ${hour >= 12 ? "PM" : "AM"}`
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-xl">HockeySubFinder</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <span className="text-sm font-medium text-primary">Dashboard</span>
            <span className="text-sm font-medium">Calendar</span>
            <span className="text-sm font-medium">Profile</span>
            <span className="text-sm font-medium">Messages</span>
          </nav>
          <div className="flex items-center gap-2">
            <div className="text-sm mr-2">John Smith</div>
            <button className="rounded-full p-2 hover:bg-gray-100">
              <User className="h-5 w-5" />
              <span className="sr-only">User</span>
            </button>
          </div>
        </div>
      </header>
      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-8">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-gray-500">Manage your hockey sub requests and availability</p>
          </div>

          <div className="w-full">
            <div className="flex border-b">
              <button
                className={`px-4 py-2 ${activeTab === "player" ? "border-b-2 border-blue-600 text-blue-600" : ""}`}
                onClick={() => setActiveTab("player")}
              >
                Player View
              </button>
              <button
                className={`px-4 py-2 ${activeTab === "team" ? "border-b-2 border-blue-600 text-blue-600" : ""}`}
                onClick={() => setActiveTab("team")}
              >
                Team Manager View
              </button>
            </div>

            <div className="mt-6 space-y-6">
              {activeTab === "player" ? (
                <>
                  <div className="bg-white p-6 rounded-lg shadow">
                    <div className="mb-4">
                      <h2 className="text-xl font-semibold">Available Sub Opportunities</h2>
                      <p className="text-gray-500">Games looking for substitute players</p>
                    </div>
                    <div className="grid gap-4">
                      {subRequests.map((game) => (
                        <div key={game.id} className="border rounded-lg p-4">
                          <div className="flex flex-col md:flex-row justify-between gap-4">
                            <div className="space-y-2">
                              <h3 className="font-bold">{game.teamName}</h3>
                              <div className="flex items-center gap-2 text-sm text-gray-500">
                                <Calendar className="h-4 w-4" />
                                <span>{formatDate(game.date)}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-500">
                                <Clock className="h-4 w-4" />
                                <span>{formatTime(game.time)}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-500">
                                <MapPin className="h-4 w-4" />
                                <span>{game.location}</span>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <h4 className="font-medium">Positions Needed:</h4>
                              <div className="flex flex-wrap gap-2">
                                {game.positionsNeeded.map((position) => (
                                  <span
                                    key={position}
                                    className="bg-blue-100 text-blue-600 px-2 py-1 rounded-full text-xs"
                                  >
                                    {position.charAt(0).toUpperCase() + position.slice(1)}
                                  </span>
                                ))}
                              </div>
                              <button className="w-full mt-2 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                                Apply to Sub
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg shadow">
                    <div className="mb-4">
                      <h2 className="text-xl font-semibold">My Availability</h2>
                      <p className="text-gray-500">Set when you're available to play</p>
                    </div>
                    <div className="grid gap-4">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => (
                          <button key={day} className="border rounded px-4 py-2 text-left hover:bg-gray-50">
                            {day}
                          </button>
                        ))}
                      </div>
                      <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 w-full md:w-auto">
                        Update Availability
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="bg-white p-6 rounded-lg shadow">
                    <div className="flex flex-col md:flex-row justify-between items-start mb-4">
                      <div>
                        <h2 className="text-xl font-semibold">My Sub Requests</h2>
                        <p className="text-gray-500">Manage your team's substitute requests</p>
                      </div>
                      <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mt-2 md:mt-0">
                        <Plus className="inline-block mr-2 h-4 w-4" /> New Request
                      </button>
                    </div>
                    <div className="grid gap-4">
                      {subRequests.map((request) => (
                        <div key={request.id} className="border rounded-lg p-4">
                          <div className="flex flex-col md:flex-row justify-between gap-4">
                            <div className="space-y-2">
                              <h3 className="font-bold">{request.teamName}</h3>
                              <div className="flex items-center gap-2 text-sm text-gray-500">
                                <Calendar className="h-4 w-4" />
                                <span>{formatDate(request.date)}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-500">
                                <Clock className="h-4 w-4" />
                                <span>{formatTime(request.time)}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-500">
                                <MapPin className="h-4 w-4" />
                                <span>{request.location}</span>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <h4 className="font-medium">Positions Needed:</h4>
                              <div className="flex flex-wrap gap-2">
                                {request.positionsNeeded.map((position) => (
                                  <span
                                    key={position}
                                    className="bg-blue-100 text-blue-600 px-2 py-1 rounded-full text-xs"
                                  >
                                    {position.charAt(0).toUpperCase() + position.slice(1)}
                                  </span>
                                ))}
                              </div>
                              <div className="flex gap-2 mt-2">
                                <button className="border px-4 py-2 rounded hover:bg-gray-50 flex-1">Edit</button>
                                <button className="border px-4 py-2 rounded hover:bg-gray-50 flex-1">
                                  View Applicants
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg shadow">
                    <div className="flex flex-col md:flex-row justify-between items-start mb-4">
                      <div>
                        <h2 className="text-xl font-semibold">Goalie Registry</h2>
                        <p className="text-gray-500">Find available goalies for your games</p>
                      </div>
                      <button className="border px-4 py-2 rounded hover:bg-gray-50 mt-2 md:mt-0">View Goalies</button>
                    </div>
                    <p className="text-gray-500">
                      Access our exclusive registry of available goalies. Contact them directly to arrange
                      substitutions.
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </main>
      <footer className="border-t py-6">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">© 2025 HockeySubFinder. All rights reserved.</p>
          <nav className="flex gap-4">
            <span className="text-sm text-gray-500 hover:underline">Terms</span>
            <span className="text-sm text-gray-500 hover:underline">Privacy</span>
            <span className="text-sm text-gray-500 hover:underline">Contact</span>
          </nav>
        </div>
      </footer>
    </div>
  )
}
