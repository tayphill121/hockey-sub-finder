import { NextResponse } from "next/server"

// Mock data for demonstration
const users = [
  {
    id: "user1",
    name: "John Smith",
    email: "john@example.com",
    role: "player",
    positions: ["Forward"],
    availability: ["Monday", "Wednesday", "Friday"],
    isPaid: true,
    createdAt: "2025-01-10T08:00:00Z",
  },
]

export async function GET() {
  // In a real app, you would fetch from a database with proper authentication
  return NextResponse.json(users)
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.name || !data.email || !data.role) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Check if email already exists
    if (users.some((user) => user.email === data.email)) {
      return NextResponse.json({ error: "Email already exists" }, { status: 400 })
    }

    // In a real app, you would hash the password and save to a database
    const newUser = {
      id: "user" + (users.length + 1),
      ...data,
      isPaid: false,
      createdAt: new Date().toISOString(),
    }

    // Mock adding to database
    users.push(newUser)

    return NextResponse.json(newUser, { status: 201 })
  } catch (error) {
    console.error("Error creating user:", error)
    return NextResponse.json({ error: "Error creating user" }, { status: 500 })
  }
}
