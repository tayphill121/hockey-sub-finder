import NextAuth from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import { compare, hash } from "bcryptjs"

// In a real app, you would use a database
// This is a simplified in-memory store for demo purposes
const users = [
  {
    id: "1",
    name: "Demo User",
    email: "user@example.com",
    // This is "password" hashed
    password: "$2b$10$8OxDlUjXBF.KFH9YvH0FoOzqP7s4Yb.IQR5/UQZQvrBRwGWwrHhPy",
    role: "player",
    playerType: "regular",
    isPaid: true,
  },
  {
    id: "2",
    name: "Team Manager",
    email: "manager@example.com",
    // This is "password" hashed
    password: "$2b$10$8OxDlUjXBF.KFH9YvH0FoOzqP7s4Yb.IQR5/UQZQvrBRwGWwrHhPy",
    role: "team",
    isPaid: true,
  },
  {
    id: "3",
    name: "Demo Goalie",
    email: "goalie@example.com",
    // This is "password" hashed
    password: "$2b$10$8OxDlUjXBF.KFH9YvH0FoOzqP7s4Yb.IQR5/UQZQvrBRwGWwrHhPy",
    role: "player",
    playerType: "goalie",
    isPaid: true, // Goalies are automatically paid
  },
]

export const authOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        const user = users.find((user) => user.email === credentials.email)
        if (!user) {
          return null
        }

        const isPasswordValid = await compare(credentials.password, user.password)
        if (!isPasswordValid) {
          return null
        }

        return {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
        token.role = user.role
        token.playerType = user.playerType
        token.isPaid = user.isPaid
      }
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id
        session.user.role = token.role
        session.user.playerType = token.playerType
        session.user.isPaid = token.isPaid
      }
      return session
    },
  },
  pages: {
    signIn: "/login",
  },
  session: {
    strategy: "jwt",
  },
}

// For registering new users (simplified for demo)
export async function registerUser(userData) {
  const { name, email, password, role, playerType } = userData

  // Check if user already exists
  if (users.some((user) => user.email === email)) {
    throw new Error("User already exists")
  }

  const hashedPassword = await hash(password, 10)
  const newUser = {
    id: (users.length + 1).toString(),
    name,
    email,
    password: hashedPassword,
    role,
    playerType: role === "player" ? playerType : undefined,
    // Goalies are automatically paid
    isPaid: role === "player" && playerType === "goalie",
  }

  users.push(newUser)
  return {
    id: newUser.id,
    name,
    email,
    role,
    playerType: newUser.playerType,
    isPaid: newUser.isPaid,
  }
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }
