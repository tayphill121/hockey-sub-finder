import { NextResponse } from "next/server"

// Mock data for demonstration
const subRequests = [
  {
    id: "1",
    teamId: "team1",
    teamName: "Maple Leafs",
    date: "2025-05-10",
    time: "19:00",
    location: "City Ice Arena",
    positionsNeeded: ["Forward", "Defense"],
    description: "Regular season game, need 2 subs.",
    createdAt: "2025-04-23T12:00:00Z",
  },
  {
    id: "2",
    teamId: "team2",
    teamName: "Bruins",
    date: "2025-05-15",
    time: "20:30",
    location: "Community Rink",
    positionsNeeded: ["Goalie"],
    description: "Our regular goalie is out of town.",
    createdAt: "2025-04-24T14:30:00Z",
  },
]

export async function GET() {
  // In a real app, you would fetch from a database
  return NextResponse.json(subRequests)
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.teamId || !data.date || !data.time || !data.location || !data.positionsNeeded) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // In a real app, you would save to a database
    const newRequest = {
      id: Date.now().toString(),
      ...data,
      createdAt: new Date().toISOString(),
    }

    // Mock adding to database
    subRequests.push(newRequest)

    return NextResponse.json(newRequest, { status: 201 })
  } catch (error) {
    console.error("Error creating sub request:", error)
    return NextResponse.json({ error: "Error creating sub request" }, { status: 500 })
  }
}
