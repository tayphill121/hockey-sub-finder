"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"
import { useSession } from "next-auth/react"

const formSchema = z.object({
  cardNumber: z.string().min(16, { message: "Please enter a valid card number." }),
  cardholderName: z.string().min(2, { message: "Please enter the cardholder name." }),
  expiryDate: z.string().regex(/^\d{2}\/\d{2}$/, { message: "Please use MM/YY format." }),
  cvc: z.string().min(3, { message: "Please enter a valid CVC." }),
})

export default function PaymentPage() {
  const router = useRouter()
  const { data: session, status } = useSession()
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    // If user is a goalie, redirect to dashboard
    if (session?.user?.role === "player" && session?.user?.playerType === "goalie") {
      router.push("/dashboard")
    }

    // If user is already paid, redirect to dashboard
    if (session?.user?.isPaid) {
      router.push("/dashboard")
    }
  }, [session, router])

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cardNumber: "",
      cardholderName: "",
      expiryDate: "",
      cvc: "",
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true)

    try {
      // This would connect to your payment processor
      // const response = await processPayment(values)

      toast({
        title: "Payment successful!",
        description: "Your $25 seasonal subscription has been processed.",
      })

      // Redirect to dashboard after successful payment
      setTimeout(() => {
        router.push("/dashboard")
      }, 2000)
    } catch (error) {
      toast({
        title: "Payment failed",
        description: "There was an issue processing your payment. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Show loading state while checking session
  if (status === "loading") {
    return (
      <div className="container flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4">Loading...</p>
        </div>
      </div>
    )
  }

  const accountType = session?.user?.role === "team" ? "Team" : "Player"
  const subscriptionType = session?.user?.role === "team" ? "Team Subscription" : "Player Subscription"
  const subscriptionDescription =
    session?.user?.role === "team"
      ? "Access to the substitute player network and goalie registry for one full season"
      : "Access to the substitute player network for one full season"

  return (
    <div className="container flex items-center justify-center min-h-screen py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold">Payment</CardTitle>
          <CardDescription>Complete your $25 seasonal {accountType.toLowerCase()} subscription</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
            <div className="flex justify-between">
              <span>{subscriptionType}</span>
              <span className="font-bold">$25.00</span>
            </div>
            <div className="text-sm text-gray-500 mt-2">{subscriptionDescription}</div>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="cardholderName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cardholder Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Smith" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="cardNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Card Number</FormLabel>
                    <FormControl>
                      <Input placeholder="4242 4242 4242 4242" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="expiryDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Expiry Date</FormLabel>
                      <FormControl>
                        <Input placeholder="MM/YY" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="cvc"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CVC</FormLabel>
                      <FormControl>
                        <Input placeholder="123" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Processing..." : "Pay $25.00"}
              </Button>
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-xs text-gray-500">Secure payment processing. Your card information is encrypted.</p>
        </CardFooter>
      </Card>
    </div>
  )
}
